from django.conf.urls import patterns, url, include, handler404, handler500
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib import admin

urlpatterns = patterns('',
    url(r'^backend/', include('simplecms.backend_urls')),
)

from django.conf import settings
SIMPLECMS_REPLACE_ADMIN_INDEX = getattr(settings, "SIMPLECMS_REPLACE_ADMIN_INDEX", True)
if SIMPLECMS_REPLACE_ADMIN_INDEX:
    urlpatterns += patterns('',
        url(r'^admin/$', 'simplecms.backend.pages'),
        url(r'^admin/', include(admin.site.urls)),
        url(r'^orig_admin/$', staff_member_required(admin.site.index), name="orig-admin-index"),
        url(r'^orig_admin/', include(admin.site.urls)),
    )

urlpatterns += patterns('',
    url(r'^$|^(?P<path>.*)$', 'simplecms.views.render_page'),
)
