from django.db.models.signals import class_prepared
from django.utils.datastructures import SortedDict
from copy import copy

_snippet_models = SortedDict()


def register_model(sender, **kwargs):
    if "Snippet" in [cls.__name__ for cls in sender.__bases__]:
        if not sender.__name__ in _snippet_models:
            _snippet_models[sender.__name__] = sender
class_prepared.connect(register_model)


def get_snippet_models():
    return _snippet_models.values()


_snippet_settings = {}


def set_snippet_settings(snippet_type, key, value):
    _snippet_settings[(snippet_type, key)] = value


def get_snippet_settings(snippet_type, key, default=None):
    return _snippet_settings.get((snippet_type, key), default)


_dashboard_panes = []


def add_dashboard_pane(pane):
    _dashboard_panes.append(pane)


def get_dashboard_panes():
    return copy(_dashboard_panes)


_link_providers = []


def add_link_provider(provider):
    _link_providers.append(provider)


def get_link_providers():
    return copy(_link_providers)


_templates = []
_template_by_slug = {}


def add_template(template):
    if template in _templates:
        raise ValueError("template %s added twice to registry" % template)
    _templates.append(template)
    _template_by_slug[template.slug] = template


def get_template(slug):
    return _template_by_slug[slug]


def get_templates():
    return _templates
