"""
Central registry for registering tag-specific logic.
"""

_handlers = {}

def unregister(tag, handler):
    _handlers[tag].remove(handler)
    return True

def register(tag, handler):
    if tag not in _handlers:
        _handlers[tag] = set([handler])
    else:
        _handlers[tag].add(handler)
    return True

def dispatch(request, context, tag):
    functions = _handlers.get(tag)
    if not functions:
        return
    for f in functions:
        context.update(f(request, context, tag))
