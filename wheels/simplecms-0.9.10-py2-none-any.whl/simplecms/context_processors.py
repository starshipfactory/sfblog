from simplecms.models import Page

def get_page(request):
    try:
        page = Page.objects.from_path(request.path_info, online=True)
    except Page.DoesNotExist:
        page = None
    return {'simplecms_page': page, 'simplecms_url': request.path_info}
