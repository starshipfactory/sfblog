from django.dispatch import Signal

#
# signal sent before rendering a Page. receiver should return
# None or a response
#
pre_render = Signal(providing_args=["request", "page"])
