from django.contrib.syndication.views import Feed
from django.utils.feedgenerator import Atom1Feed

from simplecms.models import Page

class SimpleCMSFeedDescendants(Feed):
    description_template = "simplecms/feeds/page_description.html"
    feed_type = Atom1Feed
    root = Page.objects

    def items(self):
        root = self.root
        if callable(root):
            root = root()
        return root.get_descendants().filter(_show_online=True)

    def item_title(self, obj):
        return obj.title
