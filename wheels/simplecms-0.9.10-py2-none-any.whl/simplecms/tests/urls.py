from django.conf.urls import (patterns, include, url, handler404,
        handler500)
from django.contrib import admin
from django.conf import settings
admin.autodiscover()

from simplecms.sitemap import PageSitemap
try:
    from localeurl.sitemaps import LocaleurlSitemap
    sitemaps = {}
    for lcode, lname in settings.LANGUAGES:
        sitemaps['pages-%s' % lcode] = PageSitemap(lcode)
except ImportError:
    sitemaps = {
        'pages': PageSitemap(),
    }


def lala(request):
    from django import http
    return http.HttpResponse("lala")


urlpatterns = patterns('',
    url(r'^accounts/', include("django.contrib.auth.urls")),
    url(r'^foo/bar/$', lala, name="lala"),
    url(r'^sitemap/$', 'simplecms.views.sitemap', name='sitemap'),
    url(r'^sitemap\.xml$', 'django.contrib.sitemaps.views.sitemap',
        {'sitemaps': sitemaps}),
    url(r'^', include(settings.OLD_ROOT_URLCONF)),
)
