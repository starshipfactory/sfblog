# -*- encoding: utf-8 -*-

import os
import sys
from StringIO import StringIO
from django.test import TestCase
from django.conf import settings
from django.core.urlresolvers import reverse
from django.contrib.auth.models import User
from django.utils.datastructures import SortedDict
from django.forms.models import ModelMultipleChoiceField

from simplecms.models import Page, Content
from simplecms.template import Template, TemplateBlock, serialize_template_info
from simplecms import registry

# url fixup sick monkey hack
settings.OLD_ROOT_URLCONF = settings.ROOT_URLCONF
from simplecms.tests import urls


class CommonSetupMixin(object):
    def commonTearDown(self):
        settings.ROOT_URLCONF = self.old_urlconf
        settings.TEMPLATE_DIRS = self.old_template_dirs

        registry._templates = []
        registry._template_by_slug = {}

    def commonSetUp(self):
        self.old_urlconf = settings.ROOT_URLCONF
        self.old_template_dirs = settings.TEMPLATE_DIRS
        settings.ROOT_URLCONF = urls.__name__
        settings.TEMPLATE_DIRS += (
            os.path.join(os.path.normpath(os.path.abspath(os.path.dirname(__file__))),
                "templates"),
        )
        settings.LANGUAGE_CODE = "de"
        settings.LANGUAGES = (("de", "Deutsch"), ("en", "English"))
        from django.utils import translation
        translation.activate(settings.LANGUAGE_CODE)
        Page.tree.rebuild()

        registry._templates = []
        registry._template_by_slug = {}

        tempdefault = Template(name="Default",
                               slug="default",
                               path="simplecms/content.html",
                               desc="default template")
        tempdefault.add_block(TemplateBlock(name="content",
                                            slug="content"))
        registry.add_template(tempdefault)


class BackendViewTests(TestCase, CommonSetupMixin):
    def tearDown(self):
        self.commonTearDown()

    def setUp(self):
        self.commonSetUp()

        self.tempdefault = Template.get_by_slug("default")

        self.temp1 = Template(name="Custom",
                              desc="Custom",
                              path="custom/custom.html",
                              slug="custom")
        registry.add_template(self.temp1)

        self.nav1 = Page.objects.create(slug="main",
                                        title="Main Navigation",
                                        online=True,
                                        in_navigation=True)

        self.galerien = Page.objects.create(slug="galerien",
                                            title="Galerien",
                                            parent=self.nav1,
                                            online=True,
                                            in_navigation=True)

        self.twentyten = Page.objects.create(slug="2010",
                                             title="2010",
                                             parent=self.nav1,
                                             online=True,
                                             in_navigation=True)

        c = self.twentyten.content
        c.template_slug = self.temp1.slug
        c.save()

        self.start = Page.objects.create(slug="/", title="Startseite",
                                         parent=self.nav1, online=True,
                                         in_navigation=True)
        self.testcontent1 = Page.objects.create(slug="testcontent1",
                                                title="Testcontent1",
                                                parent=self.nav1, online=True,
                                                in_navigation=True)

        self.nav2 = Page.objects.create(slug="bottom",
                                        title="Bottom Navigation", online=True,
                                        in_navigation=True)
        self.imp = Page.objects.create(slug="impressum", title="Impressum",
                                       parent=self.nav2)
        self.kont = Page.objects.create(slug="testkontakt", title="Kontakt",
                                        parent=self.nav2)
        self.about = Page.objects.create(slug="ueber", title="About",
                                         parent=self.nav2, online=True,
                                         in_navigation=True)
        self.sub = Page.objects.create(slug="unter", title="Unter uns",
                                       parent=self.about, online=True,
                                       in_navigation=True)
        self.off = Page.objects.create(slug="offline", title="Off the line",
                                       parent=self.about, online=False,
                                       in_navigation=True)
        self.belowoff = Page.objects.create(
            slug="below_offline",
            title="Below a page that is offline",
            parent=self.off, online=True,
            in_navigation=True)

        self.user = User.objects.create(**{
            'first_name': 'Alexander',
            'last_name': 'Clausen',
            'username': 'alex',
            'email': 'alex@gc-web.de',
            'is_superuser': True,
            'is_staff': True,
            'is_active': True
        })
        self.user.set_password('test')
        self.user.save()

        self.user2 = User.objects.create(**{
            'first_name': 'Alexander2',
            'last_name': 'Clausen2',
            'username': 'alex2',
            'email': 'alex@gc-web.de',
            'is_active': True
        })
        self.user2.set_password('test')
        self.user2.save()

        Page.objects.update_denorm()

    def doLogin(self, user, pw, next="/backend/"):
        resp = self.client.post(reverse('django.contrib.auth.views.login'), {
            'username': user,
            'password': pw,
            'next': next,
        })
        self.assertRedirects(resp, next)
        return resp

    def testOrigAdmin(self):
        self.doLogin("alex", "test")
        resp = self.client.get("/orig_admin/")
        self.assertTemplateUsed(resp, "admin/base.html")

    def testLoginRequired(self):
        def _test_login_req(urlname, *args):
            resp = self.client.get(reverse(urlname, args=args))
            self.assertRedirects(resp, "/accounts/login/?next="
                                 + reverse(urlname, args=args))
        _test_login_req("simplecms-backend-pages")
        _test_login_req("simplecms-backend-toggle-prop")
        _test_login_req("simplecms-backend-page-move")
        _test_login_req("simplecms-backend-page-delete", 0)
        _test_login_req("simplecms-backend-page-add")
        _test_login_req("simplecms-backend-page-edit", 0)

    def testStaffReq(self):
        self.doLogin("alex2", "test", next="/")

        def _test_login_req(urlname, *args):
            resp = self.client.get(reverse(urlname, args=args))
            self.assertRedirects(resp, "/accounts/login/?next=" + reverse(urlname, args=args))
        _test_login_req("simplecms-backend-pages")
        _test_login_req("simplecms-backend-toggle-prop")
        _test_login_req("simplecms-backend-page-move")
        _test_login_req("simplecms-backend-page-delete", 0)
        _test_login_req("simplecms-backend-page-add")
        _test_login_req("simplecms-backend-page-edit", 0)

    def testSimpleMove(self):
        self.doLogin('alex', 'test')
        resp = self.client.post(reverse("simplecms-backend-page-move"), {
            'page_id': Page.objects.from_path("/ueber/").id,
            'dest_id': Page.objects.from_path("/2010/").id,
            'drop_position': 'first-child',
        })
        self.assertEquals(resp.status_code, 200)

    def testGetOnlyPages(self):
        self.doLogin("alex", "test")

        resp = self.client.get(reverse("simplecms-backend-pages"))
        self.assertTemplateUsed(resp, "simplecms/backend/page/index.html")
        self.assertContains(resp, "Impressum")
        self.assertContains(resp, "Kontakt")
        self.assertContains(resp, "Startseite")
        # TODO: ...

    def testAdd(self):
        self.doLogin("alex", "test")
        resp = self.client.get(reverse("simplecms-backend-page-add"))
        self.assertTemplateUsed(resp, "simplecms/backend/page/edit.html")
        self.assertTemplateUsed(resp, "simplecms/backend/snippets/editor.html")

        # XXX need to generate a valid formset for the
        # XXX current set of snippet types.
        # XXX simplecms.registry.get_snippet_models()

        raw = {}  # override data
        data = SortedDict()
        total = {
            'textsnippet': 2,
        }
        fields = {}

        # management form data
        for m in registry.get_snippet_models():
            name = m.__name__.lower()
            f_inst = m.get_backend_form()()
            fields[name] = {}
            for field in f_inst:
                fields[name][field.name] = field.field.initial
            data['%s_set-INITIAL_FORMS' % name] = [u'0']
            data['%s_set-TOTAL_FORMS' % name] = [unicode(total.get(name, 1))]
            data['%s_set-MAX_NUM_FORMS' % name] = [u'1000']

        for m in registry.get_snippet_models():
            name = m.__name__.lower()
            f_inst = m.get_backend_form()()
            for i in range(total.get(name, 2) - 1):
                for field, def_val in fields[name].items():
                    # XXX empty <select>s submit a different value (none..)
                    # than empty inputs/textareas/...
                    dont_submit_val = isinstance(
                        f_inst[field].field,
                        ModelMultipleChoiceField
                    )
                    if def_val is None and not dont_submit_val:
                        def_val = u''
                    val = raw.get((name, i, field), def_val)
                    if val is None:
                        continue
                    data['%s_set-%d-%s' % (name, i, field)] = [val]
                data['%s_set-%d-snippet_ptr' % (name, i)] = [u'']

        data['created_0'] = [u'17.03.2011']
        data['created_1'] = [u'20:17:00']
        data['keywords'] = [u'']
        data['content-template_slug'] = [u'default']
        data['initial-content-template_slug'] = [u'default']
        data['in_navigation'] = [u'on']
        data['title'] = [u'test']
        data['description'] = [u'']
        data['parent'] = [u'1']
        data['slug'] = [u'test']

        data[u'textsnippet_set-1-body'] = [u'<p>\r\n\ttest</p>\r\n']
        data[u'textsnippet_set-1-block_slug'] = [u'content']
        data[u'textsnippet_set-1-content'] = [u'']
        data[u'textsnippet_set-1-snippet_ptr'] = [u'']
        data[u'textsnippet_set-1-style'] = [u'']
        data[u'textsnippet_set-1-order'] = [u'7']

        resp = self.client.post(reverse("simplecms-backend-page-add"), data)
        # XXX debug output
        if resp.status_code != 302:
            print "pageform errors:", resp.context['pageform'].errors
            print "contentform errors:", resp.context['contentform'].errors
            print "formsets:"
            print resp.context[0]
            for formset in resp.context['formsets']:
                if len(formset.errors[0]) > 0:
                    print formset.prefix
                    print formset.errors
                    for i, errs in enumerate(formset):
                        for field_name in errs:
                            key = "%s-%d-%s" % (formset.prefix, i,
                                                field_name.name)
                            print key
                            print field_name
                            print data.get(key)
                            print '\n'
                    for form in formset:
                        print form.changed_data
                        for name in form.changed_data:
                            form[name]

        self.assertRedirects(resp, reverse("simplecms-backend-pages"))

        data['title'] = u""
        resp = self.client.post(reverse("simplecms-backend-page-add"), data)
        self.assertTemplateUsed(resp, "simplecms/backend/page/edit.html")
        self.assertTemplateUsed(resp, "simplecms/backend/snippets/editor.html")

        # TODO: check for error message(s)
        # TODO: test other snippets

    def testEdit(self):
        self.doLogin("alex", "test")
        resp = self.client.get(reverse("simplecms-backend-page-edit",
                                       args=[Page.objects.from_path("/2010/").id]))
        self.assertTemplateUsed(resp, "simplecms/backend/page/edit.html")
        self.assertTemplateUsed(resp, "simplecms/backend/snippets/editor.html")
        # TODO: post


class PageStaticTests(TestCase):
    fixtures = ["test_fixture.json"]

    def setUp(self):
        Page.objects.rebuild()
        Page.objects.update_denorm()

    def _page_id(self, p, i):
        p = Page.objects.from_path(p)
        self.assertEquals(p.pk, i)

    def testPathLookup(self):
        self._page_id("/", 3)
        self._page_id("/galerien/", 2)
        self._page_id("/ueber/", 8)
        self._page_id("/testkontakt/", 7)
        self._page_id("/impressum/", 6)
        self._page_id("/testcontent1/", 4)
        self.assertRaises(Page.DoesNotExist, self._page_id, "/testcontent1/blah/", 0)
        self.assertRaises(Page.DoesNotExist, self._page_id, "/galerien/slug/1/2/3/", 0)


class PageDynamicTests(TestCase, CommonSetupMixin):
    def tearDown(self):
        self.commonTearDown()

    def setUp(self):
        self.commonSetUp()

        self.defaulttemp = Template.get_by_slug(slug="default")
        self.contentblock = self.defaulttemp.get_block(slug="content")

        self.temp1 = Template(name="Custom",
                              desc="Custom",
                              path="custom/custom.html",
                              slug="custom")
        registry.add_template(self.temp1)

        self.nav1 = Page.objects.create(slug="main", title="Main Navigation",
                                        online=True, in_navigation=True)
        self.galerien = Page.objects.create(slug="galerien", title="Galerien",
                                            parent=self.nav1, online=True,
                                            in_navigation=True)
        self.twentyten = Page.objects.create(slug="2010", title="2010",
                                             parent=self.nav1, online=True,
                                             in_navigation=True)
        c = self.twentyten.content
        c.template_slug = self.temp1.slug
        c.save()

        self.start = Page.objects.create(slug="/", title="Startseite",
                                         parent=self.nav1, online=True,
                                         in_navigation=True)
        self.testcontent1 = Page.objects.create(slug="testcontent1",
                                                title="Testcontent1",
                                                parent=self.nav1, online=True,
                                                in_navigation=True)

        self.nav2 = Page.objects.create(slug="bottom",
                                        title="Bottom Navigation", online=True,
                                        in_navigation=True)
        self.imp = Page.objects.create(slug="impressum", title="Impressum",
                                       parent=self.nav2)
        self.kont = Page.objects.create(slug="testkontakt", title="Kontakt",
                                        parent=self.nav2)
        self.about = Page.objects.create(slug="ueber", title="About",
                                         parent=self.nav2, online=True,
                                         in_navigation=True)
        self.sub = Page.objects.create(slug="unter", title="Unter uns",
                                       parent=self.about, online=True,
                                       in_navigation=True)
        self.off = Page.objects.create(slug="offline", title="Off the line",
                                       parent=self.about, online=False,
                                       in_navigation=True)
        self.belowoff = Page.objects.create(
            slug="below_offline",
            title="Below a page that is offline",
            parent=self.off, online=True,
            in_navigation=True)

        Page.objects.update_denorm()

    def _page_ref(self, p, ref):
        p = Page.objects.from_path(p)
        self.assertEquals(p.pk, ref.pk)

    def testPathLookup(self):
        self._page_ref("/", self.start)
        #self._page_ref("/galerien/", self.galerien)
        self._page_ref("/2010/", self.twentyten)
        self._page_ref("/ueber/", self.about)
        self._page_ref("/testkontakt/", self.kont)
        self._page_ref("/impressum/", self.imp)
        self._page_ref("/testcontent1/", self.testcontent1)
        self.assertRaises(Page.DoesNotExist, self._page_ref, "/testcontent1/blah/", self.start)
        self.assertRaises(Page.DoesNotExist, self._page_ref, "/galerien/slug/1/2/3/", self.start)

        self.assertEquals(self.nav1.pk, Page.objects.get_nav("main").pk)
        self.assertEquals(self.nav2.pk, Page.objects.get_nav("bottom").pk)

    def testPathLookupClient(self):
        resp = self.client.get("/galerien/")
        self.assertEquals(resp.status_code, 200)

        resp = self.client.get("/2010/")
        self.assertTemplateUsed(resp, "simplecms/custom/custom.html")

        resp = self.client.get("/ueber/")
        self.assertTemplateUsed(resp, "simplecms/content.html")

        resp = self.client.get("/ueber/offline/")
        self.assertEquals(resp.status_code, 404)  # offline

        resp = self.client.get("/testkontakt/")
        self.assertEquals(resp.status_code, 404)  # offline

        resp = self.client.get("/impressum/")
        self.assertEquals(resp.status_code, 404)  # also offline

        resp = self.client.get("/testcontent1/")
        self.assertTemplateUsed(resp, "simplecms/content.html")

    def testPagesOnline(self):
        self.assertEquals(list(Page.objects.online()), [self.nav1, self.galerien, self.twentyten,
                                                        self.start, self.testcontent1, self.nav2,
                                                        self.about, self.sub])

    def testPageRepr(self):
        self.assertEquals(repr(self.about), "<Page: /ueber/>")

    def testPageBelowHomepage(self):
        p = Page.objects.create(slug="below-home-page", title="Below Homepage", parent=self.start)
        Page.objects.update_denorm()
        self._page_ref("/below-home-page/", p)

    def testNavRootProps(self):
        # need to reload the obj to make sure the tree information is correct:
        obj = Page.objects.get_nav(slug="main")

        self.assert_(obj.is_nav_root())
        self.assert_(not obj.is_app_node())
        self.assert_(not obj.is_deletable())
        self.assert_(not obj.is_leaf_in_nav())
        self.assert_(not obj.is_movable())
        self.assert_(not obj.is_movable_same_parent())
        self.assert_(not obj.is_homepage())
        self.assert_(obj.show_online())
        self.assert_(obj.show_in_navigation())
        self.assert_(obj.can_have_children())
        self.assert_(not obj.can_have_content())
        self.assertEquals(obj.get_absolute_url(), None)
        self.assertEquals(list(obj.get_breadcrumb_pages()), [])
        self.assertEquals(obj.get_path(), "/")

    def testHomepageProps(self):
        obj = Page.objects.from_path("/")
        self.assert_(not obj.is_nav_root())
        self.assert_(not obj.is_app_node())
        self.assert_(not obj.is_deletable())
        self.assert_(obj.is_leaf_node())
        self.assert_(obj.is_leaf_in_nav())
        self.assert_(obj.is_movable())
        self.assert_(obj.is_movable_same_parent())
        self.assert_(obj.is_homepage())
        self.assert_(obj.show_online())
        self.assert_(obj.show_in_navigation())
        self.assert_(obj.can_have_children())
        self.assert_(obj.can_have_content())
        self.assertEquals(obj.get_absolute_url(), "/")
        self.assertEquals(list(obj.get_breadcrumb_pages()), [])
        self.assertEquals(obj.get_path(), "/")

    def testContentLeafProps(self):
        obj = Page.objects.from_path("/testcontent1/")
        self.assert_(not obj.is_nav_root())
        self.assert_(not obj.is_app_node())
        self.assert_(obj.is_deletable())
        self.assert_(obj.is_leaf_node())
        self.assert_(obj.is_leaf_in_nav())
        self.assert_(obj.is_movable())
        self.assert_(not obj.is_movable_same_parent())
        self.assert_(not obj.is_homepage())
        self.assert_(obj.show_online())
        self.assert_(obj.show_in_navigation())
        self.assert_(obj.can_have_children())
        self.assert_(obj.can_have_content())
        self.assertEquals(obj.get_absolute_url(), "/testcontent1/")
        self.assertEquals(list(obj.get_breadcrumb_pages()), [])
        self.assertEquals(obj.get_path(), "/testcontent1/")

    def testContentLeafProps2(self):
        obj = Page.objects.from_path("/2010/")
        self.assert_(not obj.is_nav_root())
        self.assert_(not obj.is_app_node())
        self.assert_(obj.is_deletable())
        self.assert_(obj.is_leaf_node())
        self.assert_(obj.is_leaf_in_nav())
        self.assert_(obj.is_movable())
        self.assert_(not obj.is_movable_same_parent())
        self.assert_(not obj.is_homepage())
        self.assert_(obj.show_online())
        self.assert_(obj.show_in_navigation())
        self.assert_(obj.can_have_children())
        self.assert_(obj.can_have_content())
        self.assertEquals(obj.get_absolute_url(), "/2010/")
        self.assertEquals(list(obj.get_breadcrumb_pages()), [])
        self.assertEquals(obj.get_path(), "/2010/")

    def testOfflineProps(self):
        obj = Page.objects.from_path("/ueber/offline/")
        self.assert_(not obj.is_nav_root())
        self.assert_(not obj.is_app_node())
        self.assert_(obj.is_deletable())
        self.assert_(not obj.is_leaf_node())
        self.assert_(obj.is_leaf_in_nav())
        self.assert_(obj.is_movable())
        self.assert_(not obj.is_movable_same_parent())
        self.assert_(not obj.is_homepage())
        self.assert_(not obj.show_online())
        self.assert_(not obj.show_in_navigation())  # even though in_navigation=True!
                                                    # because of online=False
        self.assert_(obj.can_have_children())
        self.assert_(obj.can_have_content())
        self.assertEquals(obj.get_absolute_url(), "/ueber/offline/")
        self.assertEquals(list(obj.get_breadcrumb_pages()), [Page.objects.from_path("/ueber/")])
        self.assertEquals(obj.get_path(), "/ueber/offline/")

    def testBelowOfflineProps(self):
        obj = Page.objects.from_path("/ueber/offline/below_offline/")
        self.assert_(not obj.is_nav_root())
        self.assert_(not obj.is_app_node())
        self.assert_(obj.is_deletable())
        self.assert_(obj.is_leaf_node())
        self.assert_(obj.is_leaf_in_nav())
        self.assert_(obj.is_movable())
        self.assert_(not obj.is_movable_same_parent())
        self.assert_(not obj.is_homepage())

        # because the parent is offline:
        self.assert_(not obj.show_online())
        self.assert_(not obj.show_in_navigation())

        self.assert_(obj.can_have_children())
        self.assert_(obj.can_have_content())
        self.assertEquals(obj.get_absolute_url(), "/ueber/offline/below_offline/")
        self.assertEquals(list(obj.get_breadcrumb_pages()),
                          [Page.objects.from_path("/ueber/"),
                           Page.objects.from_path("/ueber/offline/")])
        self.assertEquals(obj.get_path(), "/ueber/offline/below_offline/")

    def testInnerNodeProps(self):
        obj = Page.objects.from_path("/ueber/")
        self.assert_(not obj.is_nav_root())
        self.assert_(not obj.is_app_node())
        self.assert_(obj.is_deletable())
        self.assert_(not obj.is_leaf_node())
        self.assert_(not obj.is_leaf_in_nav())
        self.assert_(obj.is_movable())
        self.assert_(not obj.is_movable_same_parent())
        self.assert_(not obj.is_homepage())
        self.assert_(obj.show_online())
        self.assert_(obj.show_in_navigation())
        self.assert_(obj.can_have_children())
        self.assert_(obj.can_have_content())
        self.assertEquals(obj.get_absolute_url(), "/ueber/")
        self.assertEquals(list(obj.get_breadcrumb_pages()), [])
        self.assertEquals(obj.get_path(), "/ueber/")

    def _galerie_props(self, obj):
        self.assert_(not obj.is_nav_root())
        self.assert_(obj.is_app_node())
        self.assert_(not obj.is_deletable())
        self.assert_(not obj.is_leaf_node())
        self.assert_(obj.is_leaf_in_nav())
        self.assert_(obj.is_movable())
        self.assert_(obj.is_movable_same_parent())
        self.assert_(not obj.is_homepage())
        self.assert_(obj.show_online())
        self.assert_(obj.show_in_navigation())
        self.assert_(not obj.can_have_children())
        self.assert_(obj.can_have_content())
        self.assertEquals(list(obj.get_breadcrumb_pages()), [])

    def testLinksJSON(self):
        resp = self.client.get(reverse("simplecms-backend-links"))
        self.assertEquals(resp.content, "")


class TestManagementCommands(TestCase, CommonSetupMixin):
    def tearDown(self):
        self.commonTearDown()

    def setUp(self):
        self.commonSetUp()

        self.template = Template.get_by_slug(slug="default")
        self.contentblock = self.template.get_block("content")

    def testCreateNav(self):
        orig_stdout = sys.stdout
        orig_stderr = sys.stderr
        try:
            sys.stdout = StringIO()
            sys.stderr = StringIO()
            from django.core import management

            def _invalid1():
                management.call_command("simplecms_create_nav", "new1", "Neue Navigation",
                                        verbosity=0)
                management.call_command("simplecms_create_nav", "new1", "Neue Navigation",
                                        verbosity=0)
            self.assertRaises(SystemExit, _invalid1)
            management.call_command("simplecms_create_nav", "newnav", "Neue Navigation",
                                    verbosity=0)
            obj = Page.objects.get_nav("newnav")
            self.assert_(obj.is_nav_root())
        finally:
            sys.stdout = orig_stdout
            sys.stderr = orig_stderr

    def testInit(self):
        from django.core import management
        orig_stdout = sys.stdout
        orig_stderr = sys.stderr
        try:
            sys.stdout = StringIO()
            sys.stderr = StringIO()
            management.call_command("simplecms_init")
            main = Page.objects.get_nav("main")
            self.assert_(main.is_nav_root())
        finally:
            sys.stdout = orig_stdout
            sys.stderr = orig_stderr

        home = Page.objects.from_path("/")
        self.assertEquals(home.parent, main)


class TestFrontEndViews(TestCase, CommonSetupMixin):
    fixtures = ["test_fixture.json"]

    def tearDown(self):
        self.commonTearDown()

    def setUp(self):
        self.commonSetUp()
        Page.objects.rebuild()
        Page.objects.update_denorm()

    def testRedirect(self):
        resp = self.client.get("/testcontent1")
        # permanent
        self.assertRedirects(resp, "/testcontent1/", status_code=301)

    def testDoesNotExistOrOffline(self):
        resp = self.client.get("/does/not/exist/")
        self.assertEquals(resp.status_code, 404)

        # /ueber/ is offline
        resp = self.client.get("/ueber/")
        self.assertEquals(resp.status_code, 404)

        # /ueber/ is offline, but /ueber/online/ is online
        offlContent = Content.objects.create()
        Page.objects.create(slug="online", online=True,
                            content=offlContent,
                            parent=Page.objects.from_path("/ueber/"))
        resp = self.client.get("/ueber/online/")
        self.assertEquals(resp.status_code, 404)

    def testSitemap(self):
        resp = self.client.get("/sitemap/")
        self.assertTemplateUsed(resp, "simplecms/sitemap.html")
        # TODO: add list of pages that should appear on the sitemap

    def testSitemapXML(self):
        resp = self.client.get("/sitemap.xml")
        self.assertEquals(resp.status_code, 200)
        # TODO: add list of pages that should appear on the sitemap


class TestTranslation(TestCase):
    def setUp(self):
        pass


class TemplateInfoTests(TestCase):
    def setUp(self):
        self.t1 = Template(
            name="Default",
            slug="default",
            desc="Default-Template",
            path="content.html",
        )
        self.b1 = TemplateBlock(name="Center", slug="center")
        self.b2 = TemplateBlock(name="Left", slug="left")
        self.t1.add_block(self.b1)
        self.t1.add_block(self.b2)
        self.maxDiff = None

    def tearDown(self):
        registry._templates = []
        registry._template_by_slug = {}

    def testRegisterTemplate(self):
        self.assertEquals(registry.get_templates(), [])
        registry.add_template(self.t1)
        self.assertEquals(registry.get_templates(), [self.t1])

    def testSerializeTemplates(self):
        self.assertEquals(registry.get_templates(), [])
        registry.add_template(self.t1)
        self.assertEquals(registry.get_templates(), [self.t1])

        self.assertEquals(serialize_template_info(), {
            'templates': {
                'default': {
                    'name': 'Default',
                    'slug': 'default',
                    'blocks': ['default.center', 'default.left'],
                }
            },
            'blocks': {
                'default.center': {
                    'id': 'default.center',
                    'name': 'Center',
                    'slug': 'center',
                    'order': 0,
                },
                'default.left': {
                    'id': 'default.left',
                    'name': 'Left',
                    'slug': 'left',
                    'order': 1,
                },
            },
        })

        self.assertEquals(self.t1, Template.get_by_slug('default'))
        self.assertEquals(self.t1, Template.get_default())
        self.assertEquals(self.t1.get_full_path(), "simplecms/content.html")
        self.assertEquals(self.t1.get_block("center"), self.b1)
        self.assertEquals(self.t1.get_block("left"), self.b2)

        def _add_twice():
            registry.add_template(self.t1)

        self.assertRaises(ValueError, _add_twice)


# TODO: write test for: link provider(s), registry functionality,
# TODO: snippet rendering, blocks, excerpts, AppPage.get_extra_nav(),
# TODO: Snippet.__unicode__, other Snippet methods, Fragment.__unicode__,
# TODO: management commands,
