from django.contrib.sitemaps import Sitemap
from simplecms.models import Page


class PageSitemap(Sitemap):
    changefreq = "weekly"

    def items(self):
        return [p for p in Page.objects.online() if p.get_absolute_url()]

    def lastmod(self, obj):
        return obj.modified
