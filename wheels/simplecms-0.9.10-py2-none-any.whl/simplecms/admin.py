from django.contrib import admin
from simplecms.models import Fragment, AppPage
from simplecms.snippet_editor import AdminSnippetEditor


class FragmentAdmin(admin.ModelAdmin):
    prepopulated_fields = {'slug': ('name',)}
admin.site.register(Fragment, FragmentAdmin)


class AppPageAdmin(admin.ModelAdmin):
    list_display = ('page', 'url_name')
admin.site.register(AppPage, AppPageAdmin)


class ContentAdmin(admin.ModelAdmin):
    editor = AdminSnippetEditor()

    def change_view(self, request, object_id, extra_context=None):
        if request.method == 'POST':
            return self.editor.post(request, object_id)
        else:
            return self.editor.get(request, object_id)

    def add_view(self, request, form_url='', extra_context=None):
        if request.method == 'POST':
            return self.editor.post(request)
        else:
            return self.editor.get(request)
