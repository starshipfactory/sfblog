import logging
import json
from django.shortcuts import get_object_or_404, redirect
from django.core.exceptions import MultipleObjectsReturned
from django.views.decorators.http import require_http_methods
from django.template.response import TemplateResponse
from django.contrib.auth.decorators import user_passes_test
from django.contrib import messages
from django.db.transaction import (commit_on_success, commit_manually, commit,
        rollback)
from django import http
from django.utils.translation import ugettext as _, get_language_info
from django.conf import settings

from mptt.exceptions import InvalidMove

from simplecms.models import Page, Content
from simplecms.forms import TranslateForm
from simplecms import registry

require_staff = user_passes_test(lambda u: u.is_active and u.is_staff)

log = logging.getLogger(__name__)


@require_staff
def links(request):
    links = []
    for prov in registry.get_link_providers():
        links.extend(list(prov().get_links()))
    return http.HttpResponse(json.dumps(links),
                             mimetype="application/json")


@require_staff
def pages(request, lang=None, template_name="simplecms/backend/page/index.html"):
    if lang is None:
        return redirect("simplecms-backend-pages", settings.LANGUAGE_CODE)
    qs = Page.objects.filter(locale=lang).prefetch_related(
        "translations", "parent", "app_page", "content")
    context = {
        'pages': qs,
        'content_locale': lang,
    }
    return TemplateResponse(request, template_name, context=context)


@require_staff
@commit_on_success
@require_http_methods(["POST"])
def delete(request, page_id, lang):
    page = get_object_or_404(Page, pk=page_id)
    if not page.is_deletable():
        return http.HttpResponseBadRequest("Page may not be deleted")
    page.children.update(parent=page.parent)
    page.delete()
    messages.add_message(request, messages.SUCCESS, _("Page deleted"))
    Page.objects.update_denorm()
    return http.HttpResponse("")


@require_staff
@require_http_methods(["POST"])
@commit_on_success
def toggle(request, lang):
    try:
        page_id = request.POST['page_id']
        prop = request.POST['property']
    except KeyError:
        return http.HttpResponseBadRequest("Bad property")
    props = ["online", "in_navigation"]
    page = get_object_or_404(Page, pk=page_id)
    if not prop in props:
        return http.HttpResponseBadRequest("Bad property")
    setattr(page, prop, not getattr(page, prop))
    page.save()
    new_value = getattr(page, prop)
    Page.objects.update_denorm()
    return http.HttpResponse(str(new_value).lower())


@require_staff
@require_http_methods(["POST"])
@commit_manually
def move(request, lang):
    try:
        page_id = request.POST["page_id"]
        dest_id = request.POST["dest_id"]
        drop_position = request.POST["drop_position"]
        assert(drop_position in ["left", "right", "first-child"])
    except KeyError:
        rollback()
        return http.HttpResponseBadRequest("Bad Request #0")

    page = get_object_or_404(Page, pk=page_id)
    dest = get_object_or_404(Page, pk=dest_id)

    if page == dest and drop_position == "right":
        if not page.get_next_sibling():
            dest = dest.parent

    if dest is None:
        rollback()
        return http.HttpResponseBadRequest(
            "Bad Request: can't move this page #0")

    if drop_position == "first-child":
        parent = dest
    else:
        parent = dest.parent

    if parent is None:
        rollback()
        return http.HttpResponseBadRequest(
            "Bad Request: can't move this page #1")
    else:
        if not (page.is_movable() and parent.can_have_children()):
            rollback()
            return http.HttpResponseBadRequest(
                "Bad Request: can't move this page #2")

    if page.is_movable_same_parent():
        if drop_position == "left":
            old_parent = dest.parent
        elif drop_position == "right":
            old_parent = dest.parent
        elif drop_position == "first-child":
            old_parent = dest
        if page.parent != old_parent:
            rollback()
            return http.HttpResponseBadRequest(
                "Bad Request: can't move to different parent")

    try:
        page.move_to(dest, drop_position)
    except InvalidMove:
        rollback()
        return http.HttpResponseBadRequest(
            "Bad Request: can't move this page #3")

    Page.objects.update_denorm()
    page = Page.objects.get(pk=page_id)
    try:
        Page.objects.from_path(page.get_path(), locale=lang)
    except (Page.DoesNotExist, MultipleObjectsReturned), e:
        log.error("can't move %s %s of %s: %s (page.get_path() == %s)"
            % (page, drop_position, dest, repr(e), page.get_path()))
        rollback()
        return http.HttpResponseBadRequest(
            "Bad Request: can't move this page #4 (%s)" % repr(e))

    commit()
    return http.HttpResponse("ok")


@require_staff
@commit_on_success
@require_http_methods(["GET", "POST"])
def translate(request, page_id, lang, to_lang,
              template_name="simplecms/backend/page/translate.html"):
    page = get_object_or_404(Page, pk=page_id)
    translated = page.get_translation(to_lang)
    if translated is not None:
        messages.add_message(request, messages.NOTICE,
                             _("Page already translated to %s")
                             % get_language_info(lang)['name'])
        return redirect("simplecms-backend-pages", lang=lang)
    # if source page parent has translation, automatically set new parent
    initial = {}
    parent_in_dest_lang = page.parent.get_translation(to_lang)
    if parent_in_dest_lang:
        initial['parent'] = parent_in_dest_lang
    form = TranslateForm(to_lang, request.POST or None, initial=initial)
    if form.is_valid():
        new_content = Content.objects.create()
        page.content.clone(new_content)
        new_page = form.save(commit=False)
        new_page.content = new_content
        new_page.locale = to_lang
        new_page.save()
        new_page.translations.add(page)
        form.save_m2m()
        for s in page.content.snippets():
            s_new = s.__class__()
            s.clone(s_new)
            s_new.content = new_content
            s_new.save()
        Page.objects.update_denorm()
        messages.add_message(request, messages.SUCCESS,
                             _("Page successfully cloned"))
        return redirect("simplecms-backend-page-edit", lang=to_lang, obj_id=new_page.id)

    context = {
        'form': form,
        'from_lang': lang,
        'page': page,
        'to_lang': to_lang,
        'content_locale': lang,
    }

    return TemplateResponse(request, template_name, context=context)
