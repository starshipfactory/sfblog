# encoding: utf-8
import datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models

class Migration(SchemaMigration):

    def forwards(self, orm):
        
        # Adding field 'TemplateBlock.order'
        db.add_column('simplecms_templateblock', 'order', self.gf('django.db.models.fields.PositiveIntegerField')(default=0), keep_default=False)


    def backwards(self, orm):
        
        # Deleting field 'TemplateBlock.order'
        db.delete_column('simplecms_templateblock', 'order')


    models = {
        'simplecms.apppage': {
            'Meta': {'object_name': 'AppPage'},
            'app_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'page': ('django.db.models.fields.related.OneToOneField', [], {'related_name': "'app_page'", 'unique': 'True', 'to': "orm['simplecms.Page']"}),
            'regex': ('django.db.models.fields.TextField', [], {}),
            'url_name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        'simplecms.appsnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'AppSnippet', '_ormbases': ['simplecms.Snippet']},
            'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'})
        },
        'simplecms.content': {
            'Meta': {'object_name': 'Content'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'template': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['simplecms.Template']", 'null': 'True'})
        },
        'simplecms.fragment': {
            'Meta': {'object_name': 'Fragment'},
            'body': ('django.db.models.fields.TextField', [], {}),
            'created': ('model_utils.fields.AutoCreatedField', [], {'default': 'datetime.datetime.now'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'modified': ('model_utils.fields.AutoLastModifiedField', [], {'default': 'datetime.datetime.now'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '50', 'db_index': 'True'})
        },
        'simplecms.fragmentsnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'FragmentSnippet', '_ormbases': ['simplecms.Snippet']},
            'fragment': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['simplecms.Fragment']"}),
            'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'})
        },
        'simplecms.imagesnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'ImageSnippet', '_ormbases': ['simplecms.Snippet']},
            'description': ('django.db.models.fields.TextField', [], {'default': "''", 'blank': 'True'}),
            'image': ('imagetools.models.ThumbnailField', [], {'max_length': '100'}),
            'image_height': ('django.db.models.fields.IntegerField', [], {}),
            'image_width': ('django.db.models.fields.IntegerField', [], {}),
            'size': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'}),
            'style': ('django.db.models.fields.CharField', [], {'max_length': '100', 'null': 'True', 'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        'simplecms.page': {
            'Meta': {'ordering': "['tree_id', 'lft']", 'object_name': 'Page'},
            '_full_path': ('django.db.models.fields.TextField', [], {'null': 'True', 'blank': 'True'}),
            '_show_in_navigation': ('django.db.models.fields.NullBooleanField', [], {'null': 'True', 'blank': 'True'}),
            '_show_online': ('django.db.models.fields.NullBooleanField', [], {'null': 'True', 'blank': 'True'}),
            'content': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['simplecms.Content']", 'unique': 'True'}),
            'created': ('model_utils.fields.AutoCreatedField', [], {'default': 'datetime.datetime.now'}),
            'description': ('django.db.models.fields.TextField', [], {'default': "''", 'null': 'True', 'blank': 'True'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'in_navigation': ('django.db.models.fields.BooleanField', [], {'default': 'True', 'db_index': 'True', 'blank': 'True'}),
            'keywords': ('django.db.models.fields.TextField', [], {'default': "''", 'null': 'True', 'blank': 'True'}),
            'level': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'lft': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'modified': ('model_utils.fields.AutoLastModifiedField', [], {'default': 'datetime.datetime.now'}),
            'online': ('django.db.models.fields.BooleanField', [], {'default': 'False', 'db_index': 'True', 'blank': 'True'}),
            'parent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'children'", 'null': 'True', 'to': "orm['simplecms.Page']"}),
            'rght': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'slug': ('django.db.models.fields.CharField', [], {'max_length': '255', 'db_index': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'tree_id': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'})
        },
        'simplecms.snippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'Snippet'},
            'block': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['simplecms.TemplateBlock']", 'null': 'True'}),
            'content': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['simplecms.Content']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {})
        },
        'simplecms.template': {
            'Meta': {'object_name': 'Template'},
            'description': ('django.db.models.fields.TextField', [], {'default': "''"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '100'}),
            'path': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        'simplecms.templateblock': {
            'Meta': {'unique_together': "(('template', 'slug'),)", 'object_name': 'TemplateBlock'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '50', 'db_index': 'True'}),
            'template': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['simplecms.Template']"})
        },
        'simplecms.textsnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'TextSnippet', '_ormbases': ['simplecms.Snippet']},
            'body': ('django.db.models.fields.TextField', [], {}),
            'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'}),
            'style': ('django.db.models.fields.CharField', [], {'max_length': '100', 'null': 'True', 'blank': 'True'})
        },
        'simplecms.videosnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'VideoSnippet', '_ormbases': ['simplecms.Snippet']},
            'description': ('django.db.models.fields.TextField', [], {}),
            'height': ('django.db.models.fields.PositiveIntegerField', [], {'default': '240'}),
            'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'}),
            'style': ('django.db.models.fields.CharField', [], {'max_length': '100', 'null': 'True', 'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'url': ('django.db.models.fields.URLField', [], {'max_length': '200'}),
            'width': ('django.db.models.fields.PositiveIntegerField', [], {'default': '320'})
        }
    }

    complete_apps = ['simplecms']
