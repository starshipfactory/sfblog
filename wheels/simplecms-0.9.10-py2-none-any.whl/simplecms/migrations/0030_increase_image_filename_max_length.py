# -*- coding: utf-8 -*-
from south.utils import datetime_utils as datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):

        # Changing field 'ImageSnippet.image'
        db.alter_column(u'simplecms_imagesnippet', 'image', self.gf('imagetools.models.ThumbnailField')(max_length=255))

    def backwards(self, orm):

        # Changing field 'ImageSnippet.image'
        db.alter_column(u'simplecms_imagesnippet', 'image', self.gf('imagetools.models.ThumbnailField')(max_length=100))

    models = {
        u'simplecms.apppage': {
            'Meta': {'object_name': 'AppPage'},
            'app_name': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '100', 'blank': 'True'}),
            'can_have_children': ('django.db.models.fields.BooleanField', [], {}),
            'description': ('django.db.models.fields.TextField', [], {'default': "''"}),
            'edit_link': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '100', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'namespace': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '100', 'blank': 'True'}),
            'page': ('mptt.fields.TreeOneToOneField', [], {'related_name': "'app_page'", 'unique': 'True', 'to': u"orm['simplecms.Page']"}),
            'url_name': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '100'})
        },
        u'simplecms.appsnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'AppSnippet', '_ormbases': [u'simplecms.Snippet']},
            u'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'})
        },
        u'simplecms.content': {
            'Meta': {'object_name': 'Content'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'template_slug': ('django.db.models.fields.SlugField', [], {'default': "'default'", 'max_length': '50', 'db_column': "'template'"})
        },
        u'simplecms.fragment': {
            'Meta': {'object_name': 'Fragment'},
            'body': ('django.db.models.fields.TextField', [], {}),
            'created': ('model_utils.fields.AutoCreatedField', [], {'default': 'datetime.datetime.now'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'modified': ('model_utils.fields.AutoLastModifiedField', [], {'default': 'datetime.datetime.now'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'slug': ('django.db.models.fields.SlugField', [], {'max_length': '50'})
        },
        u'simplecms.fragmentsnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'FragmentSnippet', '_ormbases': [u'simplecms.Snippet']},
            'fragment': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['simplecms.Fragment']"}),
            u'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'})
        },
        u'simplecms.imagesnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'ImageSnippet', '_ormbases': [u'simplecms.Snippet']},
            'description': ('django.db.models.fields.TextField', [], {'default': "''", 'blank': 'True'}),
            'image': ('imagetools.models.ThumbnailField', [], {'max_length': '255'}),
            'image_height': ('django.db.models.fields.IntegerField', [], {}),
            'image_width': ('django.db.models.fields.IntegerField', [], {}),
            'link': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '200', 'blank': 'True'}),
            'link_target': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '25', 'blank': 'True'}),
            'size': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            u'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'}),
            'style': ('django.db.models.fields.CharField', [], {'max_length': '100', 'null': 'True', 'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'simplecms.page': {
            'Meta': {'ordering': "['tree_id', 'lft']", 'object_name': 'Page'},
            '_full_path': ('django.db.models.fields.TextField', [], {'null': 'True', 'blank': 'True'}),
            '_show_in_navigation': ('django.db.models.fields.NullBooleanField', [], {'null': 'True', 'blank': 'True'}),
            '_show_online': ('django.db.models.fields.NullBooleanField', [], {'null': 'True', 'blank': 'True'}),
            'content': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['simplecms.Content']", 'unique': 'True'}),
            'created': ('model_utils.fields.AutoCreatedField', [], {'default': 'datetime.datetime.now'}),
            'description': ('django.db.models.fields.TextField', [], {'default': "''", 'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'in_navigation': ('django.db.models.fields.BooleanField', [], {'default': 'True', 'db_index': 'True'}),
            'keywords': ('django.db.models.fields.TextField', [], {'default': "''", 'null': 'True', 'blank': 'True'}),
            u'level': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            u'lft': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'locale': ('django.db.models.fields.CharField', [], {'default': "''", 'max_length': '5', 'db_index': 'True'}),
            'modified': ('model_utils.fields.AutoLastModifiedField', [], {'default': 'datetime.datetime.now'}),
            'online': ('django.db.models.fields.BooleanField', [], {'default': 'False', 'db_index': 'True'}),
            'parent': ('mptt.fields.TreeForeignKey', [], {'blank': 'True', 'related_name': "'children'", 'null': 'True', 'to': u"orm['simplecms.Page']"}),
            u'rght': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'slug': ('django.db.models.fields.CharField', [], {'max_length': '255', 'db_index': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'translations': ('mptt.fields.TreeManyToManyField', [], {'related_name': "'translations_rel_+'", 'blank': 'True', 'to': u"orm['simplecms.Page']"}),
            u'tree_id': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'})
        },
        u'simplecms.snippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'Snippet'},
            'block_slug': ('django.db.models.fields.SlugField', [], {'default': "''", 'max_length': '50', 'db_column': "'block'"}),
            'content': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['simplecms.Content']"}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {})
        },
        u'simplecms.textsnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'TextSnippet', '_ormbases': [u'simplecms.Snippet']},
            'body': ('django.db.models.fields.TextField', [], {}),
            u'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'}),
            'style': ('django.db.models.fields.CharField', [], {'max_length': '100', 'null': 'True', 'blank': 'True'})
        },
        u'simplecms.videosnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'VideoSnippet', '_ormbases': [u'simplecms.Snippet']},
            'description': ('django.db.models.fields.TextField', [], {}),
            'height': ('django.db.models.fields.PositiveIntegerField', [], {'default': '240'}),
            u'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': u"orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'}),
            'style': ('django.db.models.fields.CharField', [], {'max_length': '100', 'null': 'True', 'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'url': ('django.db.models.fields.URLField', [], {'max_length': '200'}),
            'width': ('django.db.models.fields.PositiveIntegerField', [], {'default': '320'})
        }
    }

    complete_apps = ['simplecms']