# encoding: utf-8
import datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models

class Migration(SchemaMigration):

    def forwards(self, orm):
        
        # Adding model 'Page'
        db.create_table('simplecms_page', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('created', self.gf('model_utils.fields.AutoCreatedField')(default=datetime.datetime.now)),
            ('modified', self.gf('model_utils.fields.AutoLastModifiedField')(default=datetime.datetime.now)),
            ('title', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('slug', self.gf('django.db.models.fields.CharField')(max_length=255, db_index=True)),
            ('online', self.gf('django.db.models.fields.BooleanField')(default=False, db_index=True, blank=True)),
            ('in_navigation', self.gf('django.db.models.fields.BooleanField')(default=True, db_index=True, blank=True)),
            ('parent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='children', null=True, to=orm['simplecms.Page'])),
            ('content', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['simplecms.Content'], unique=True)),
            ('lft', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            ('rght', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            ('tree_id', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            ('level', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
        ))
        db.send_create_signal('simplecms', ['Page'])

        # Adding model 'AppPage'
        db.create_table('simplecms_apppage', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('page', self.gf('django.db.models.fields.related.OneToOneField')(related_name='app_page', unique=True, to=orm['simplecms.Page'])),
            ('app_name', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('url_name', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('regex', self.gf('django.db.models.fields.TextField')()),
        ))
        db.send_create_signal('simplecms', ['AppPage'])

        # Adding model 'Template'
        db.create_table('simplecms_template', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('description', self.gf('django.db.models.fields.TextField')(default='')),
            ('path', self.gf('django.db.models.fields.CharField')(max_length=100)),
        ))
        db.send_create_signal('simplecms', ['Template'])

        # Adding model 'Content'
        db.create_table('simplecms_content', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('template', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['simplecms.Template'], null=True, blank=True)),
        ))
        db.send_create_signal('simplecms', ['Content'])

        # Adding model 'Snippet'
        db.create_table('simplecms_snippet', (
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('content', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['simplecms.Content'])),
            ('order', self.gf('django.db.models.fields.PositiveIntegerField')()),
        ))
        db.send_create_signal('simplecms', ['Snippet'])

        # Adding model 'AppSnippet'
        db.create_table('simplecms_appsnippet', (
            ('snippet_ptr', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['simplecms.Snippet'], unique=True, primary_key=True)),
        ))
        db.send_create_signal('simplecms', ['AppSnippet'])

        # Adding model 'TextSnippet'
        db.create_table('simplecms_textsnippet', (
            ('snippet_ptr', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['simplecms.Snippet'], unique=True, primary_key=True)),
            ('body', self.gf('django.db.models.fields.TextField')()),
            ('style', self.gf('django.db.models.fields.CharField')(max_length=100, null=True, blank=True)),
        ))
        db.send_create_signal('simplecms', ['TextSnippet'])

        # Adding model 'ImageSnippet'
        db.create_table('simplecms_imagesnippet', (
            ('snippet_ptr', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['simplecms.Snippet'], unique=True, primary_key=True)),
            ('title', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('description', self.gf('django.db.models.fields.TextField')(default='', blank=True)),
            ('style', self.gf('django.db.models.fields.CharField')(max_length=100, null=True, blank=True)),
            ('size', self.gf('django.db.models.fields.CharField')(max_length=100)),
            ('image', self.gf('imagetools.models.ThumbnailField')(max_length=100)),
            ('image_width', self.gf('django.db.models.fields.IntegerField')()),
            ('image_height', self.gf('django.db.models.fields.IntegerField')()),
        ))
        db.send_create_signal('simplecms', ['ImageSnippet'])

        # Adding model 'VideoSnippet'
        db.create_table('simplecms_videosnippet', (
            ('snippet_ptr', self.gf('django.db.models.fields.related.OneToOneField')(to=orm['simplecms.Snippet'], unique=True, primary_key=True)),
            ('title', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('description', self.gf('django.db.models.fields.TextField')()),
            ('url', self.gf('django.db.models.fields.URLField')(max_length=200)),
            ('width', self.gf('django.db.models.fields.PositiveIntegerField')(default=320)),
            ('height', self.gf('django.db.models.fields.PositiveIntegerField')(default=240)),
            ('style', self.gf('django.db.models.fields.CharField')(max_length=100, null=True, blank=True)),
        ))
        db.send_create_signal('simplecms', ['VideoSnippet'])


    def backwards(self, orm):
        
        # Deleting model 'Page'
        db.delete_table('simplecms_page')

        # Deleting model 'AppPage'
        db.delete_table('simplecms_apppage')

        # Deleting model 'Template'
        db.delete_table('simplecms_template')

        # Deleting model 'Content'
        db.delete_table('simplecms_content')

        # Deleting model 'Snippet'
        db.delete_table('simplecms_snippet')

        # Deleting model 'AppSnippet'
        db.delete_table('simplecms_appsnippet')

        # Deleting model 'TextSnippet'
        db.delete_table('simplecms_textsnippet')

        # Deleting model 'ImageSnippet'
        db.delete_table('simplecms_imagesnippet')

        # Deleting model 'VideoSnippet'
        db.delete_table('simplecms_videosnippet')


    models = {
        'simplecms.apppage': {
            'Meta': {'object_name': 'AppPage'},
            'app_name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'page': ('django.db.models.fields.related.OneToOneField', [], {'related_name': "'app_page'", 'unique': 'True', 'to': "orm['simplecms.Page']"}),
            'regex': ('django.db.models.fields.TextField', [], {}),
            'url_name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        'simplecms.appsnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'AppSnippet', '_ormbases': ['simplecms.Snippet']},
            'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'})
        },
        'simplecms.content': {
            'Meta': {'object_name': 'Content'},
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'template': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['simplecms.Template']", 'null': 'True', 'blank': 'True'})
        },
        'simplecms.imagesnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'ImageSnippet', '_ormbases': ['simplecms.Snippet']},
            'description': ('django.db.models.fields.TextField', [], {'default': "''", 'blank': 'True'}),
            'image': ('imagetools.models.ThumbnailField', [], {'max_length': '100'}),
            'image_height': ('django.db.models.fields.IntegerField', [], {}),
            'image_width': ('django.db.models.fields.IntegerField', [], {}),
            'size': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'}),
            'style': ('django.db.models.fields.CharField', [], {'max_length': '100', 'null': 'True', 'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        'simplecms.page': {
            'Meta': {'ordering': "['tree_id', 'lft']", 'object_name': 'Page'},
            'content': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['simplecms.Content']", 'unique': 'True'}),
            'created': ('model_utils.fields.AutoCreatedField', [], {'default': 'datetime.datetime.now'}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'in_navigation': ('django.db.models.fields.BooleanField', [], {'default': 'True', 'db_index': 'True', 'blank': 'True'}),
            'level': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'lft': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'modified': ('model_utils.fields.AutoLastModifiedField', [], {'default': 'datetime.datetime.now'}),
            'online': ('django.db.models.fields.BooleanField', [], {'default': 'False', 'db_index': 'True', 'blank': 'True'}),
            'parent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'children'", 'null': 'True', 'to': "orm['simplecms.Page']"}),
            'rght': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'slug': ('django.db.models.fields.CharField', [], {'max_length': '255', 'db_index': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'tree_id': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'})
        },
        'simplecms.snippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'Snippet'},
            'content': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['simplecms.Content']"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {})
        },
        'simplecms.template': {
            'Meta': {'object_name': 'Template'},
            'description': ('django.db.models.fields.TextField', [], {'default': "''"}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'path': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        'simplecms.textsnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'TextSnippet', '_ormbases': ['simplecms.Snippet']},
            'body': ('django.db.models.fields.TextField', [], {}),
            'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'}),
            'style': ('django.db.models.fields.CharField', [], {'max_length': '100', 'null': 'True', 'blank': 'True'})
        },
        'simplecms.videosnippet': {
            'Meta': {'ordering': "['order']", 'object_name': 'VideoSnippet', '_ormbases': ['simplecms.Snippet']},
            'description': ('django.db.models.fields.TextField', [], {}),
            'height': ('django.db.models.fields.PositiveIntegerField', [], {'default': '240'}),
            'snippet_ptr': ('django.db.models.fields.related.OneToOneField', [], {'to': "orm['simplecms.Snippet']", 'unique': 'True', 'primary_key': 'True'}),
            'style': ('django.db.models.fields.CharField', [], {'max_length': '100', 'null': 'True', 'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'url': ('django.db.models.fields.URLField', [], {'max_length': '200'}),
            'width': ('django.db.models.fields.PositiveIntegerField', [], {'default': '320'})
        }
    }

    complete_apps = ['simplecms']
