from django.conf.urls import patterns, url
from simplecms.snippet_editor import PageEditor
from simplecms.snippet_editor import require_staff

urlpatterns = patterns('simplecms.backend',
    url(r'^$', 'pages', name='simplecms-backend-pages'),
    url(r'^links/$', 'links', name='simplecms-backend-links'),

    url(r'^(?P<lang>[\w-]+)/$', 'pages', name='simplecms-backend-pages'),
    url(r'^(?P<lang>[\w-]+)/links/$', 'links', name='simplecms-backend-links'),
    url(r'^(?P<lang>[\w-]+)/page/toggle/$', 'toggle', name='simplecms-backend-toggle-prop'),
    url(r'^(?P<lang>[\w-]+)/page/move/$', 'move', name='simplecms-backend-page-move'),
    url(r'^(?P<lang>[\w-]+)/page/(?P<page_id>\d+)/translate/to/(?P<to_lang>\w+)/$', 'translate',
        name='simplecms-backend-page-translate'),
    url(r'^(?P<lang>[\w-]+)/page/(?P<page_id>\d+)/delete/$', 'delete',
        name='simplecms-backend-page-delete'),
)

urlpatterns += patterns('',
    url(r'^(?P<lang>[\w-]+)/page/add/$', require_staff(PageEditor.as_view()),
        name='simplecms-backend-page-add'),
    url(r'^(?P<lang>[\w-]+)/page/(?P<obj_id>\d+)/edit/$', require_staff(PageEditor.as_view()),
        name='simplecms-backend-page-edit'),
)
