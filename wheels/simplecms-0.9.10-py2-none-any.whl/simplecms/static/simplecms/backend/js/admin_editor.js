jQuery(document).ready(function($) {
    $("#id_title").focus();
    if($("#tabs").children("fieldset").find(".errors").length === 0) {
        $("#tabs").tabs();
        $("#tabs h2").css({display: "none"});
    } else {
        $("#tabs").children("ul").hide(0);
    }

    if($("#formrow-id_content-template option").length == 1) {
        $("#formrow-id_content-template").css({visibility: 'hidden'});
    }
});
