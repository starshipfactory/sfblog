if(simplecms === undefined) {
    var simplecms = {};
}

(function($) {
    simplecms.templateBlocks = function(template_info) {
        this.template_info = template_info;
        this.init();
    };

    simplecms.templateBlocks.prototype.get_block = function(form) {
        if(this.current_template === undefined) {
            console.error("current_template is undefined");
        }
        var block_slug = $(form).find(".form-row.block_slug input").val();
        var key = this.current_template + "." + block_slug;
        return template_info.blocks[key];
    };

    simplecms.templateBlocks.prototype.set_block = function(form, block) {
        form.find(".form-row.block_slug input").val(block.slug);
    };

    // returns: template slug of currently selected template
    simplecms.templateBlocks.prototype.get_current_template = function() {
        return $("#id_content-template_slug").val();
    };

    simplecms.templateBlocks.prototype.make_block_header = function(block) {
        if(block.name === undefined) {
            console.error("invalid block", block);
        }
        var block_html = $("<h2 class='block'>" + block.name + "</h2>");
        block_html.data("block", block);
        return block_html;
    };

    simplecms.templateBlocks.prototype.init = function() {
        var blocks_seen = {};
        var $$ = this;
        this.current_template = this.get_current_template();

        // add headings before the first snippet in each block
        $(".snippet_form:visible").each(function() {
            var block = $$.get_block($(this));
            if(block !== undefined && !blocks_seen[block.id]) {
                blocks_seen[block.id] = true;
                var block_header_html = $$.make_block_header(block);
                $(this).before(block_header_html);
            } else {
                return;
            }
        });

        this.update_block_headers(blocks_seen);

        $("#id_content-template_slug").change(function() {
            $$.template_changed();
        }).change();

        $(".snippet_container").bind("simplecms_sort_stop", function() {
            $$.update_snippet_blocks();
        });

        $(".snippet_container").bind("simplecms_snippet_post_clone", function() {
            $$.update_snippet_blocks();
        });

        $(".snippet_container").bind("simplecms_pre_save", function() {
            $$.update_snippet_blocks();
        });
    };

    simplecms.templateBlocks.prototype.update_block_headers = function(blocks_seen) {
        if(!this.current_template)
            return;
        // add headings for blocks that currently have no snippets
        var blocks = this.template_info.blocks;
        var keys = this.template_info.templates[this.current_template].blocks;
        for(var i = 0; i < keys.length; i++) {
            var block = blocks[keys[i]];
            if(!blocks_seen[block.id]) {
                $(".snippet_container").append(this.make_block_header(block));
            }
        }
        $("h2.block").not("h2.block:first").addClass("block-notfirst");
    };

    simplecms.templateBlocks.prototype.template_changed = function() {
        if(this.current_template == this.get_current_template()) {
            return;
        }
        this.current_template = this.get_current_template();
        if(!this.current_template) {
            $(".snippet_type_selector input").attr("disabled", "disabled");
            return;
        } else {
            $(".snippet_type_selector input").removeAttr("disabled");
        }
        var seen = {};
        $("h2.block").remove();
        var block_ids = this.template_info.templates[this.current_template].blocks;
        
        seen[block_ids[0]] = true;
        var first_block = this.template_info.blocks[block_ids[0]];
        $(".snippet_container").prepend(this.make_block_header(first_block));
        this.update_block_headers(seen);
        this.update_snippet_blocks();
    };

    simplecms.templateBlocks.prototype.update_snippet_blocks = function() {
        var $$ = this;
        var current_block;
        $(".snippet_container > *:visible").each(function() {
            if($(this).is("h2")) {
                current_block = $(this).data("block");
            } else {
                var old = $$.get_block($(this));
                if(old)
                    old = old.name;
                $.log("updating snippet blocks for", this, "to", current_block.name, "- was:", old);
                $$.set_block($(this), current_block);
            }
        });
    };

})( jQuery );
