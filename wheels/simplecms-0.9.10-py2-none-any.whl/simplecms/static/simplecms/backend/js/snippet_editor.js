/*
 * snippetEditor; depends on jquery 1.4+
 */

if(simplecms === undefined) {
    var simplecms = {};
}

(function($) {
    /***************************
     * simplecms.snippetEditor *
     ***************************/

    simplecms.snippetEditor = function(settings) {
        this.snippet_types = [];
        this.cls_to_type = {};
        this.order_next = 0;
        this.cookie_name = "simplecms_collapsed_snippets";
        this.cookie_path = settings.canonical_path || window.location.pathname;
        this.collapsed = [];
        this.settings = settings;
        this.collapsed_persistent = this.deserialize_cookie();
        this.init();
    };

    simplecms.snippetEditor.prototype.deserialize_cookie = function() {
        var raw_val = $.cookie(this.cookie_name, {path: this.cookie_path});
        var res;
        if(raw_val) {
            res = raw_val.split(",");
        } else {
            $.cookie(this.cookie_name, "", {path: this.cookie_path}); // reset cookie on error
            res = [];
        }
        return res;
    };

    simplecms.snippetEditor.prototype.serialize_cookie = function(values) {
        $.cookie(this.cookie_name, values.join(","), {path: this.cookie_path});
    };

    simplecms.snippetEditor.prototype.write_collapsed = function() {
        var res = $(".snippet_form.collapsed").map(function() {
            return $(this).find(":input:first[id^=id]").attr("id");
        }).toArray();
        this.collapsed_persistent = res;
        this.serialize_cookie(res);
    };

    simplecms.snippetEditor.prototype.collapse_from_cookie = function() {
        var collapsed_ids = this.collapsed_persistent;
        if(collapsed_ids) {
            for(var i = 0; i < collapsed_ids.length; i++) {
                var id = collapsed_ids[i];
                if(id) {
                    this.collapse($("#"+id).parents(".snippet_form"), 0);
                }
            }
        }
        this.write_collapsed();
    };

    simplecms.snippetEditor.prototype.find_snippet_types = function() {
        var ed = this;
        $(".snippet_form").each(function() {
            var classes = $(this).attr("class").split(/\s+/);
            for(var i = 0; i < classes.length; i++) {
                var cls = classes[i];
                var m = cls.match("^snippet_form_(.*)");
                if(m) {
                    if($.inArray(m[1], ed.snippet_types) == -1) {
                        ed.snippet_types.push(m[1]);
                        ed.cls_to_type[m[0]] = m[1];
                    }
                }
            }
        });
    };

    simplecms.snippetEditor.prototype.get_snippet_type = function(snippet) {
        var classes = snippet.find(".snippet_form").andSelf().attr("class").split(/\s+/);
        for(var i = 0; i < classes.length; i++) {
            var type = this.cls_to_type[classes[i]];
            if(type)
                return type;
        }
    };

    simplecms.snippetEditor.prototype.get_mgmt_form_field = function(type, varname) {
        return $("#id_" + type + "_set-" + varname);
    };

    simplecms.snippetEditor.prototype.mgmt_form_value = function(type, varname, value) {
        if(value) {
            this.get_mgmt_form_field(type, varname).val(value);
            return value;
        } else {
            var val = this.get_mgmt_form_field(type, varname).val();
            return parseInt(val, 10);
        }
    };

    /*
     * adapted from http://stackoverflow.com/questions/501719/dynamically-adding-a-form-to-a-django-formset-with-ajax
     */
    simplecms.snippetEditor.prototype.cloneMore = function(type) {
        var example = $(".snippet_form_"+type+":last");
        var newElement = $(example).clone(false);
        var total = this.mgmt_form_value(type, "TOTAL_FORMS");
        newElement.find(':input').each(function() {
            var $this = $(this);
            var name = $this.attr('name').replace(/-[0-9]+-/,'-' + total + '-');
            var id = 'id_' + name;
            $this.attr({name: name, id: id});
            if($this.attr('type') != 'hidden' || $this.attr("name").match("snippet_ptr$")) {
                $this.val('');
            }
        });
        newElement.find("div").each(function() {
            var id = $(this).attr('id').replace(/-[0-9]+-/,'-' + total + '-');
            $(this).attr({id: id});
        });
        newElement.find("label").each(function() {
            var newFor = $(this).attr('for').replace(/-[0-9]+-/,'-' + total + '-');
            $(this).attr('for', newFor);
        });
        return newElement;
    };

    simplecms.snippetEditor.prototype.renumber = function() {
        var total_count = 0;
        $(".snippet_form").each(function() {
            // only renumber those that already have an order
            var inp = $(this).find(".order input");
            if(inp.val()) {
                inp.val(total_count);
            }
            total_count += 1;
        });
        this.fix_mgmt_form();
    };

    simplecms.snippetEditor.prototype.set_field_value = function(snippet, key, value) {
        $(snippet).find(".form-row."+key+" :input,.form-row-hidden."+key+" :input").val(value);
    };

    simplecms.snippetEditor.prototype.set_defaults = function(snippet) {
        var type = this.get_snippet_type(snippet);
        var init = this.settings.initial[type];
        var keys = Object.keys(init);
        for(var i = 0; i < keys.length; i++) {
            this.set_field_value(snippet, keys[i], init[keys[i]]);
        }
        this.set_field_value(snippet, "order", "");
    };

    simplecms.snippetEditor.prototype.add_snippet = function(type) {
        var container = $(".snippet_container");
        container.triggerHandler("simplecms_snippet_pre_clone", [this, type]);
        var form = this.cloneMore(type);
        form.removeClass("form_extra");
        form.removeClass("form_removed");
        form.removeClass("form_initial");
        form.addClass("form_new");
        this.set_defaults(form);
        this.set_field_value(form, "order", this.order_next);
        form.find(".errors").removeClass("errors");
        form.find(".error").removeClass("error");
        form.find(".errorlist").remove();
        form.find(".summary").html("").hide(0);
        form.find(".DELETE").hide(0);
        form.find(".preview").html("");
        form.appendTo(container);

        this.renumber();
        this.order_next += 1;
        this.uncollapse(form);

        this.attach_snippet_listeners(form);
        
        var $$ = this;
        container.find(".snippet_form").each(function() {
            if(this != form[0]) {
                $$.collapse(this, 300);
            }
        });

        form.show(0);

        container.triggerHandler("simplecms_snippet_post_clone", [this, form, type]);
    };

    simplecms.snippetEditor.prototype.snippet_add_clicked = function() {
        var type = $(".snippet_type_selector select").val();
        this.add_snippet(type);
    };

    simplecms.snippetEditor.prototype.do_delete = function(snippet) {
        var snippet_type = this.get_snippet_type(snippet);
        $(".snippet_container").triggerHandler("simplecms_snippet_pre_delete", [this, snippet, snippet_type]);
        // check the checkbox and hide the snippet
        snippet.find(".DELETE input").attr("checked", true);
        snippet.removeClass("form_initial");
        snippet.addClass("form_removed");
        this.set_defaults(snippet);
        snippet.find(".DELETE input").removeAttr("value");
        snippet.slideUp(400);
        $(".snippet_container").triggerHandler("simplecms_snippet_post_delete", [this, snippet, snippet_type]);
    };

    simplecms.snippetEditor.prototype.collapse = function(snippet, _delay) {
        var delay = _delay || 600; 
        var ed = this;
        $(snippet).each(function() {
            $(this).triggerHandler("simplecms_pre_collapse", [ed]);
            $(this).find(".summary").show(0);
            $(this).addClass("collapsed");
            $(this).find(".form-row").not(".nohide").slideUp(delay);
            $(this).find(".collapse-link .ui-icon")
                   .removeClass("ui-icon-circle-triangle-s")
                   .addClass("ui-icon-circle-triangle-e");
        });
    };

    simplecms.snippetEditor.prototype.uncollapse = function(snippet, _delay) {
        var delay = _delay || 600; 
        var ed = this;
        $(snippet).each(function() {
            $(this).find(".summary").hide(0);
            $(this).find(".form-row").not(".DELETE").not(".block_slug").slideDown(delay);
            $(this).removeClass("collapsed");
            $(this).triggerHandler("simplecms_uncollapse", [ed]);
            $(this).find(".collapse-link .ui-icon")
                   .removeClass("ui-icon-circle-triangle-e")
                   .addClass("ui-icon-circle-triangle-s");
        });
    };

    simplecms.snippetEditor.prototype.delete_snippet_dialog = function(event) {
        var ed = event.data.ed;
        var snippet = $(this).parents(".snippet_form");
        $( "#snippet-delete-confirm" ).dialog({
            resizable: false,
            modal: true,
            buttons: {
                "Delete snippet": function() {
                    ed.do_delete(snippet);
                    $( this ).dialog( "close" );
                },
                Cancel: function() {
                    $( this ).dialog( "close" );
                }
            }
        });
        event.preventDefault();
    };

    simplecms.snippetEditor.prototype.delete_page_dialog = function() {
        var ed = this;
        $( "#page-delete-confirm" ).dialog({
            resizable: false,
            modal: true,
            buttons: {
                "Delete page": function() {
                    $.ajax({
                        url: "../delete/", 
                        success: function() { window.location.href=ed.settings.deleteRedirect; },
                        error: function(xhr, error) { ed.error_dialog("delete-page-error", error); },
                        type: "POST"
                    });

                    $(this).dialog("close");
                },
                Cancel: function() {
                    $(this).dialog("close");
                }
            }
        });
    };

    simplecms.snippetEditor.prototype.error_dialog = function(dialog_id, msg) {
        $("#" + dialog_id).dialog({
            resizable: false,
            modal: true,
            buttons: {
                Ok: function() {
                    $(this).dialog("close");
                }
            }
        });
        $("#" + dialog_id).find(".msg").html(msg);
    };

    simplecms.snippetEditor.prototype.fix_mgmt_form = function() {
        var ed = this;
        $(ed.snippet_types).each(function() {
            var count = $(".snippet_form_"+this).length;
            ed.mgmt_form_value(this, 'TOTAL_FORMS', count);
        });
    };

    simplecms.snippetEditor.prototype.attach_snippet_listeners = function(snippet) {
        var ed = this;
        $(snippet).find(".collapse-link,h2.snippet-header .name").click(function() {
            if($(snippet).hasClass("collapsed")) {
                ed.uncollapse($(snippet).get(0), 0);
                ed.write_collapsed();
            } else {
                ed.collapse($(snippet).get(0), 0);
                ed.write_collapsed();
            }
        });
        $(snippet).find(".delete-link").click({ed: ed}, ed.delete_snippet_dialog);
    };

    simplecms.snippetEditor.prototype.init = function() {
        var ed = this;
        ed.find_snippet_types();
        ed.renumber();
        $(".form-row.order input").each(function() {
            ed.order_next = parseInt($(this).val(), 10) + 1;
        });
        $(".snippet_type_selector input").click(ed.snippet_add_clicked.bind(this));

        // hide snippets marked for deletion:
        $(".form_initial").each(function() {
            var snippet = $(this);
            if(snippet.find(".DELETE input").attr("checked")) {
                $(snippet.hide(0));
            }
        });

        // 
        // sortable only works well if
        //
        // 1. all items are visible
        // 2. no handle is specified
        //

        $(".sort-link").toggle(function() {
            // start sorting
            ed.collapsed = [];
            $(".snippet_form").each(function() {
                if($(this).hasClass("collapsed")) {
                    ed.collapsed.push($(this).find(":input").attr("id"));
                }
            });
            ed.collapse($(".snippet_form"));
            $(".snippet_form").addClass("snippet-sort");
            $(".snippet_form h2").append('<span class="sort-icon right ui-icon ui-icon-arrowthick-2-n-s"></span>');
            $(".snippet_form h2").append('<span class="sort-icon left ui-icon ui-icon-arrowthick-2-n-s"></span>');
            $(".snippet_form .action-link").hide(0);
            $(".snippet_type_selector").hide(0);
            $(".snippet_editor_fields_top").slideUp(400);
            $(".submit-row").hide(0);
            $(".sort-link").text("Done sorting");
            $(".snippet_container").triggerHandler("simplecms_sort_start", [ed]);
            $(".snippet_container").sortable({
                //tolerance: 'intersect',
                tolerance: 'pointer',
                axis: 'y',
                helper: 'clone',
                forceHelperSize: true,
                forcePlaceholderSize: true,
                items: '.form_initial,.form_new,h2.block-notfirst',
                update: function(event, ui) { ed.renumber(); },
                start: function(event, ui) { $(".snippet_container").triggerHandler("simplecms_sort_start_drag", [ed, ui]); },
                stop: function(event, ui) { $(".snippet_container").triggerHandler("simplecms_sort_stop_drag", [ed, ui]); }
            });
            return false;
        }, function() {
            // done sorting
            $(".snippet_form h2").find(".sort-icon").remove();
            $(".snippet-sort").removeClass("snippet-sort");
            $(".snippet_container").sortable("destroy");
            $(".snippet_form .action-link").show(0);
            $(".snippet_type_selector").show(0);
            $(".snippet_editor_fields_top").slideDown(400);
            $(".sort-link").text("Sort");
            $(".submit-row").show(0);
            $(".snippet_form").each(function() {
                var id = $(this).find(":input").attr("id");
                if($.inArray(id, ed.collapsed) == -1) {
                    ed.uncollapse($(this));
                } 
            });
            $(".snippet_container").triggerHandler("simplecms_sort_stop", [ed]);
            return false;
        });

        $(".snippet_form").each(function() {
            ed.attach_snippet_listeners(this);
        });

        $(".delete-page-link").click(function(ev) {
            ed.delete_page_dialog();
            ev.preventDefault();
        });

        ed.collapse_from_cookie();
        $(".snippet_form .errors").parents(".snippet_form").each(function() { 
            ed.uncollapse(this, 0);
        });

        this.templateblocks = new simplecms.templateBlocks(this.settings.templates);

        $(".save-button").click(function() {
            $(".snippet_container").triggerHandler("simplecms_pre_save", [ed]);
        });

        $(".snippet_container").triggerHandler("simplecms_post_init", [this]);

        // simplecms_snippet_loaded is, possibly, triggered by a function
        // invoked by the event simplecms_post_init above
        var selected_type = $(".snippet_type_selector select").val();
        $(".snippet_container").bind("simplecms_snippet_loaded", function(ev, t) {
            $.log("simplecms_snippet_loaded", t, selected_type);
            if(t == selected_type) {
                if($(".form_initial").length === 0) {
                    ed.add_snippet(selected_type);
                }
            }
        });

        $('.hover-icons a').hover(
            //function() { $(this).addClass('ui-state-hover'); },
            //function() { $(this).removeClass('ui-state-hover'); }
        );
    };
})( jQuery );
