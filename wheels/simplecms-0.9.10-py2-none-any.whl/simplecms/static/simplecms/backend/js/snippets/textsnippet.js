$(function() {
    var ckconfig = simplecms.CKEDITOR_CONFIG;
    var textsnippets_loaded = false;
    var initialized = [];

    $(".snippet_container").bind("simplecms_snippet_post_delete", function(ev, ed, snippet, type) {
        if(type != "textsnippet")
            return;
        $.log("snippet deleted:", snippet, type);
        var id = $(snippet).find("textarea").attr("id");
        CKEDITOR.instances[id].destroy();
    });

    function wait_for_initialization(el)  {
        // as the ckeditor does not provide an event that
        // signals that the ckeditor has loaded completely,
        // we need to do some manual watching...
        // ckeditor does provide some events, but not one 
        // that is fired after the theme is loaded. but you cannot
        // destroy an editor that has no theme loaded...
        if(!CKEDITOR.instances[el.id] || !CKEDITOR.instances[el.id].theme) {
            // try again layer
            window.setTimeout(function() { wait_for_initialization(el); }, 100);
        } else {
            initialized.push(this);
        }
        if(initialized.length == $(".snippet_form_textsnippet").find("textarea").length) {
            $(".snippet_container").triggerHandler("simplecms_snippet_loaded", ["textsnippet"]);
        }
    }


    $(".snippet_container").bind("simplecms_post_init", function(ev, ed) {
        $.log("simplecms_post_init");
        $(".snippet_form_textsnippet textarea").each(function() {
            CKEDITOR.replace(this, ckconfig);
            wait_for_initialization(this);
        });
        if(textsnippets_loaded) {
            // retrigger, as the page editor may not have received the event
            $(".snippet_container").triggerHandler("simplecms_snippet_loaded", ["textsnippet"]);
        }
    });

    function destroy_instances() {
        // destroy CKEDITOR instances
        $(".snippet_form_textsnippet").find("textarea").each(function() {
            var id = $(this).attr("id");
            var inst = CKEDITOR.instances[id];
            $.log("destroying", id);
            $.log("instances before:", CKEDITOR.instances);
            if(inst) {
                if(inst.theme) {
                    inst.destroy();
                } else {
                    $.log_error("failed to destroy instance", id);
                }
            }
            $.log("instances after:", CKEDITOR.instances);
        });
    }

    $(".snippet_container").bind("simplecms_snippet_pre_clone", function(ev, ed, type) {
        if(type != "textsnippet")
            return;
        $.log("snippet pre_clone:", type);
        destroy_instances();
    });

    function reinit_instances() {
        // (re-)initialize CKEDITOR instances
        $(".snippet_form_textsnippet").find("textarea").each(function() {
            var id = $(this).attr("id");
            if(!CKEDITOR.instances[id]) {
                $.log("replacing", id);
                $.log("instances before:", CKEDITOR.instances);
                CKEDITOR.replace(id, ckconfig);
                $.log("instances after:", CKEDITOR.instances);
            }
        });
    }

    $(".snippet_container").bind("simplecms_snippet_post_clone", function(ev, ed, snippet, type) {
        if(type != "textsnippet")
            return;
        $.log("snippet post_clone:", snippet, type);
        reinit_instances();
        $(snippet).bind("simplecms_pre_collapse", pre_collapse);
    });

    function summarize(snippet) {
        var textarea = $(snippet).find("textarea");
        var text = $($(textarea).val()).text();
        try {
            text = text.trim();
        } catch(e) {}
        var append = "";
        if(text.length > 100) {
            append = "...";
        }
        return text.substr(0, 100) + append;
    }

    function pre_collapse(ev, ed) {
        // find some text:
        var id = $(this).find("textarea").attr("id");
        var inst = CKEDITOR.instances[id];
        if(inst) {
            inst.updateElement();
        }
        var text = summarize(this);
        $(this).find(".summary").html(text);
    }

    $(".snippet_form_textsnippet").bind("simplecms_pre_collapse", pre_collapse);

    $(".snippet_container").bind("simplecms_sort_start", function(ev, ed) {
        destroy_instances();
    });

    $(".snippet_container").bind("simplecms_sort_stop", function(ev, ed) {
        reinit_instances();
    });
});
