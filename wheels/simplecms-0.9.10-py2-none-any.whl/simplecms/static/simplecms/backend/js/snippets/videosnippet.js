$(function() {
    function pre_collapse(snippet) {
        var title = $(this).find(".form-row.title input").val();
        $(this).find(".summary").html(title);
    }
    function attach_snippet_listeners(snippet) {
        $(snippet).bind("simplecms_pre_collapse", pre_collapse);
    }
    $(".snippet_form_videosnippet").each(function() {
        attach_snippet_listeners(this);
    });
    $(".snippet_container").bind("simplecms_snippet_post_clone", function(ev, ed, snippet, type) {
        attach_snippet_listeners(snippet);
    });
    $(".snippet_container").bind("simplecms_post_init", function(ev, ed) {
        $(".snippet_container").triggerHandler("simplecms_snippet_loaded", ["videosnippet"]);
    });
});
