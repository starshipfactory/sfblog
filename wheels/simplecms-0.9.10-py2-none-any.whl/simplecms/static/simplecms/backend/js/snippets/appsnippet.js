$(function() {
    $(".snippet_container").bind("simplecms_post_init", function(ev, ed) {
        $(".snippet_container").triggerHandler("simplecms_snippet_loaded", ["appsnippet"]);
    });
});
