$(function() {
    function pre_collapse(ev, ed) {
        var title = $(this).find(".form-row.title input").val();
        $(this).find(".summary").html(title);
        $(this).find(".preview").attr("width", 80);
    }

    function attach_snippet_listeners(snippet) {
        $(snippet).find(".image input").change(function() {
            $(snippet).find(".preview").css({opacity: 0.1});
        });
        $(snippet).bind("simplecms_pre_collapse", pre_collapse);
        $(snippet).bind("simplecms_uncollapse", function(ev, ed) {
            $(this).find(".preview").removeAttr("width");
        });
    }

    $(".snippet_form_imagesnippet").each(function() {
        attach_snippet_listeners(this);
    });

    $(".snippet_container").bind("simplecms_snippet_post_clone", function(ev, ed, snippet, type) {
        attach_snippet_listeners(snippet);
        snippet.find("img.preview").remove();
    });

    $(".snippet_container").bind("simplecms_post_init", function(ev, ed) {
        $(".snippet_container").triggerHandler("simplecms_snippet_loaded", ["imagesnippet"]);
    });
});
