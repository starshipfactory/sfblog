jQuery(document).ready(function($) {
    var treeTableOptions = {
        initialState: "expanded", 
        indent: 25, 
        treeColumn: 0
    };

    $(".page_tree").treeTable(treeTableOptions);

    function persist_collapsed() {
        var collapsed_arr = $(".page_tree").find("tr.collapsed").map(function() { return $(this).attr("id"); }).toArray();
        $.cookie("simplecms_tree_collapsed", collapsed_arr.join(","));
    }

    // cookie persistence
    $(".page_tree .expander").click(function() {
        persist_collapsed();
    });
    try {
        var collapsed = $.cookie("simplecms_tree_collapsed");
        if(collapsed.length > 0) {
            collapsed = collapsed.split(",");
            $(collapsed).each(function() {
                $("#"+this).collapse().addClass("collapsed").removeClass("expanded");
            });
        }
    } catch(e){$.log_error("failed to load from cookie:", e); $.cookie("simplecms_tree_collapsed", "");}

    // bool toggles
    function get_page_id(tr) {
        var id = $(tr).attr("id");
        return id.split("-")[1];
    }
    function toggle_property(img, property, page_id) {
        $.post(toggle_url, {page_id: page_id, property: property}, function(data) {
            var src = $(img).attr("src");
            var old;
            if(data == "true") {
                old = "false";
            } else {
                old = "true";
            }
            $(img).attr("src", src.replace(old, data));
        });
    }
    $(".page_tree td.prop_online img").click(function() {
        toggle_property(this, "online", get_page_id($(this).parents("tr")));
    });
    $(".page_tree td.prop_in_navigation img").click(function() {
        toggle_property(this, "in_navigation", get_page_id($(this).parents("tr")));
    });


    /*
     * DND
     */
    var currentDroppable = false;
    var currentIntersection = false;
    var dropIndicator = $("<div class='drop-indicator'></div>");
    var dropDest = 'first-child';
    var valid_drop_dest = false;

    function classThatStartsWith(node, prefix) {
        var classes = $(node).attr("class").split(" ");
        var r = RegExp("^" + prefix + "(.*)");
        var res = false;
        $(classes).each(function(idx, cls) {
            var m = cls.match(r);
            if(m) {
                res = m;
                return false;
            } 
            return true;
        });
        return res;
    }

    // from http://www.quirksmode.org/js/events_properties.html
    function getMouseCoords(e) {
        var posx = 0;
        var posy = 0;
        if (!e) var e = window.event;
        if (e.pageX || e.pageY)	{
            posx = e.pageX;
            posy = e.pageY;
        }
        else if (e.clientX || e.clientY) {
            posx = e.clientX + document.body.scrollLeft
                + document.documentElement.scrollLeft;
            posy = e.clientY + document.body.scrollTop
                + document.documentElement.scrollTop;
        }
        // posx and posy contain the mouse position relative to the document
        return {posx:posx, posy:posy};
    }

    function intersect(droppable, ev) {
        var mouseY = getMouseCoords(ev).posy;
        var destTop = droppable.offset().top;
        var destHeight = droppable.height();

        var borderWidth = destHeight/3;

        if(mouseY >= destTop && mouseY < destTop+destHeight) {
            if(mouseY < destTop+borderWidth)
                return "top";
            if(mouseY >= destTop+destHeight-borderWidth)
                return "bottom";
            return "middle";
        }
        return false;
    }

    function over_handler(e, ui) {
        currentDroppable = this;

        // Make the droppable branch expand when a draggable node is moved over it.
        // ... but only after some time
        function _timed() {
            if(currentDroppable != this) 
                return;
            if(this.id != $(ui.draggable.parents("tr")[0]).id && !$(this).is(".expanded")) {
                $(this).expand();
            }
        }
        setTimeout(_timed.bind(this), 500);
    }

    /* dest_node: row where we want to drop; 
     * drop_position: one of left, right, first-child */
    function get_new_parent(dest_node, drop_position) {
        switch(drop_position) {
            case "left":
            case "right":
                return get_parent_id_of(dest_node);
            case "first-child":
                return get_page_id(dest_node);
        }
    }

    /* node: row we want to find the parent of */
    function get_parent_id_of(node) {
        var parent_id = classThatStartsWith(node, "child-of-node-");
        if(parent_id) {
            parent_id = parent_id[1];
            return parent_id;
        } else {
            return false;
        }
    }

    function drag_handler(ev, ui) {
        currentIntersection = intersect($(currentDroppable), ev);
        var draggable_row = $(this).parents("tr")[0];

        if(currentIntersection) {
            valid_drop_dest = true;

            $("body").append(dropIndicator);
            var dropOffset = $(currentDroppable).offset();
            dropOffset.left = $(currentDroppable).find("span:first").offset().left;

            var drop_page_id = get_page_id(currentDroppable);
            var drag_page_id = get_page_id(draggable_row);
            var children = $(".child-of-node-" + drop_page_id + ":visible");
            var same = (drop_page_id == drag_page_id);
            var same_parent = $(this).hasClass("is_movable_same_parent");
            var old_parent_id = get_parent_id_of(draggable_row);
            var indent_fix = 5;
            var foo_indent = treeTableOptions.indent + indent_fix;

            $.log($(".child-of-node-" + old_parent_id + ":visible:last").attr("id"));
            var draggable_is_last_sibling = $(".child-of-node-" + old_parent_id + ":visible:last").attr("id") == "node-" + drag_page_id;

            switch(currentIntersection) {
                case "top":
                    dropDest = "left";
                    if(children.length > 0) {
                        dropOffset.left += indent_fix;
                    }
                    break;
                case "bottom":
                    dropDest = "right";
                    if(children.length > 0) { // if our dest has children, drop as first-child, even on bottom
                        dropOffset.left += foo_indent;
                        dropDest = "first-child";
                    } 
                    if(same && draggable_is_last_sibling) { // bottom of ourself
                        dropOffset.left -= foo_indent;
                    }
                    dropOffset.top += $(currentDroppable).height();
                    break;
                case "middle":
                    dropDest = "first-child";
                    dropOffset.top += $(currentDroppable).height();
                    dropOffset.left += foo_indent;
                    if(same) {
                        valid_drop_dest = false;
                    }
                    break;
            }
            dropIndicator.offset(dropOffset);
            var new_parent_id = get_new_parent(currentDroppable, dropDest);

            $.log("old:", old_parent_id, "new:", new_parent_id);

            if(same_parent && old_parent_id != new_parent_id) {
                valid_drop_dest = false;
            }
            if(!$("#node-" + new_parent_id).find("span.drophere").hasClass("can_have_children")) {
                valid_drop_dest = false;
            }
        } else {
            valid_drop_dest = false;
        }

        if(!valid_drop_dest) {
            dropIndicator.remove();
        }
    }

    function drop_handler(e, ui) {
        var dest = this;

        var new_parent_id = get_page_id(dest);
        var our_page_id = get_page_id($(ui.draggable).parents("tr"));
        
        if(our_page_id == new_parent_id) {
            if(dropDest == "first-child")
                return;
        }

        $.post(move_url, {page_id: our_page_id, dest_id: new_parent_id, drop_position: dropDest}, function(response) {
            $.log("sweet success");
            // jQuery treeTable plugin can't insert left/right, only first-child. reload the page as workaround
            window.location.reload();
        });
    }

    $(".page_tree .is_movable,.page_tree .is_movable_same_parent").draggable({
            helper: "clone",
            opacity: 0.75,
            refreshPositions: true, // Performance?
            revert: "invalid",
            revertDuration: 300,
            distance: 5,
            drag: drag_handler,
            stop: function(ev, ui) { 
                persist_collapsed(); 
                dropIndicator.remove(); 
            },
            scroll: true
    });
    $(".page_tree .drophere").each(function() {
        $(this).parents("tr").droppable({
                accept: ".is_movable",
                drop: drop_handler,
                over: over_handler
        });
    });
});
