/* based on http://djangosnippets.org/snippets/1488/
 *
 * example usage:
 * $('#id_title').slugify('#id_slug');
 */

(function( $ ){
    $.fn.slugify = function(obj) {
        function replace(old) {
            return old.replace(/\s+/g,'-')
                      .replace(/[äÄ]/g,'ae')
                      .replace(/[öÖ]/g,'oe')
                      .replace(/[üÜ]/g,'ue')
                      .replace(/ß/g,'ss')
                      .replace(/[^a-zA-Z0-9\-]/gi,'')
                      .replace(/[\-]+/g, '-')
                      .toLowerCase();
        }

        function do_replace() {
            var obj = $(this).data('obj');
            var slug = replace($(this).val());
            $(this).data('obj').val(slug);
        }

        $(this).data('obj', $(obj));
        $(this).keyup(do_replace).blur(do_replace);
        return $(this);
    };
})( jQuery );
