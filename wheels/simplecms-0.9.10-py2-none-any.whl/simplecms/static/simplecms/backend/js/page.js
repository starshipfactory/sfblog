jQuery(document).ready(function($) {
    $("#id_title").focus();
    if($("#tabs").children("fieldset").find(".errors").length === 0) {
        $("#tabs").tabs({
            show: function(e, ui) {
                console.log(ui.panel);
                // resize select filter instances (admin widgets)
                var panel = $(ui.panel);
                panel.find(".selector").each(function() {
                    var new_height = $(this).find(".selector-available p").outerHeight() +
                                     $(this).find(".selector-available select").outerHeight();
                    $(this).find(".selector-chosen select").height(new_height);
                });
            }
        });
        $("#tabs h2").css({display: "none"});
    } else {
        $("#tabs").children("ul").hide(0);
    }

    if($("#formrow-id_content-template option").length == 1) {
        $("#formrow-id_content-template").css({visibility: 'hidden'});
    }
});
