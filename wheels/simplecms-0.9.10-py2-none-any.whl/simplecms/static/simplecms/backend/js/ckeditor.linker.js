CKEDITOR.on('dialogDefinition', function(ev) {
    // Take the dialog name and its definition from the event data.
    var dialogName = ev.data.name;
    var dialogDefinition = ev.data.definition;

    function myLinkTypeChanged(oldListener) {

        function _myLinkTypeChanged() {
            var dialog = this.getDialog(),
                typeValue = this.getValue();
            var element = dialog.getContentElement('info', 'simplecmsOptions');
            element = element.getElement().getParent().getParent();

            if(typeValue == "simplecms") {
                // show simplecms page selector
                element.show();
            } else {
                // hide simplecms page selector
                element.hide();
            }
            oldListener.bind(this)();
        }
        return _myLinkTypeChanged;
    }

    function myURLCommit(oldListener) {
        function _myURLCommit(data) {
            var dialog = this.getDialog();
            var type = dialog.getContentElement('info', 'linkType');
            if(type.getValue() != "simplecms") {
                oldListener.bind(this)(data);
            }
        }
        return _myURLCommit;
    }

    function repeat(str, times) {
        for(var i = 0; i < times; i++) {
            str = str.concat(str);
        }
        return str;
    }

    // Check if the definition is from the dialog we're
    // interested on (the Link dialog).
    if (dialogName == 'link') {
        //dialogDefinition.removeContents( 'advanced' );

        function addLinkType(pageList) {
            // add own link type
            var linkType = dialogDefinition.getContents('info').get('linkType');
            linkType.items.push(['SimpleCMS', 'simplecms']);
            linkType.onChange = myLinkTypeChanged(linkType.onChange);

            // preprocess pageList
            for(var i = 0; i < pageList.length; i++) {
                pageList[i][0] = repeat("--", parseInt(pageList[i][2], 10)-1) + pageList[i][0];
            }

            // override commit handler of the normal url input
            var url = dialogDefinition.getContents('info').get('url');
            url.commit = myURLCommit(url.commit);

            // add simplecmsOptions
            dialogDefinition.getContents('info').elements.push({
                type: 'vbox',
                id: 'simplecmsOptions',
                children: [
                    {
                        id: 'simplecmsPage',
                        type: 'select',
                        label: 'SimpleCMS page',
                        style: 'width: 100%',
                        items: pageList,
                        setup: function(data) {
                            var dialog = this.getDialog();
                            if(!data.url) {
                                dialog.getContentElement('info', 'linkType').setValue('simplecms');
                                return;
                            }
                            for(var j = 0; j < pageList.length; j++) {
                                if(pageList[j][1] == data.url.url) {
                                    dialog.getContentElement('info', 'linkType').setValue('simplecms');
                                    this.setValue(data.url.url);
                                    break;
                                }
                            }
                        },
                        commit: function(data) {
                            var dialog = this.getDialog();
                            var type = dialog.getContentElement('info', 'linkType');
                            //var url = dialog.getContentElement('info', 'url');

                            if(type.getValue() == "simplecms") {
                                var value = this.getValue();
                                if(!data.url) {
                                    data.url = {};
                                }
                                data.type = "url";
                                data.protocol = "";
                                data.url.url = value;
                            }
                        }
                    }
                ]
            });
        }

        // get simplecms pages, synchronously:
        jQuery.ajax({
            type: "GET",
            async: false,
            url: simplecms_links_url,
            data: {type: 'json', linkable: 1},
            dataType: 'json',
            success: addLinkType
        });

    }

});
