import logging
from django import template
from django.utils.safestring import mark_safe
from simplecms.models import Page, Fragment

register = template.Library()
log = logging.getLogger(__name__)


@register.inclusion_tag("simplecms/nav/full_tree.html", takes_context=True)
def simplecms_nav_full(context, name):
    try:
        nav_root = Page.objects.get_nav(name)
    except Page.DoesNotExist:
        return {'nodes': [], 'nav': None}

    context.update({
        'nodes': nav_root.get_descendants().select_related("app_page").filter(_show_online=True, _show_in_navigation=True),
        'nav': nav_root,
    })
    return context


@register.inclusion_tag("simplecms/nav/flat.html", takes_context=True)
def simplecms_nav_flat(context, name):
    try:
        nav_root = Page.objects.get_nav(name)
    except Page.DoesNotExist:
        return {'nodes': [], 'nav': None}

    context.update({
        'nodes': nav_root.children.select_related("app_page").filter(_show_online=True, _show_in_navigation=True),
        'nav': nav_root,
    })
    return context


# basically, simplecms_nav_full with a different template... *sigh*
@register.inclusion_tag("simplecms/nav/sitemap.html", takes_context=True)
def simplecms_sitemap(context, name):
    try:
        nav_root = Page.objects.get_nav(name)
    except Page.DoesNotExist:
        return {'nodes': [], 'nav': None}

    context.update({
        'nodes': nav_root.get_descendants().select_related("app_page").filter(_show_online=True, _show_in_navigation=True),
        'nav': nav_root,
    })
    return context


@register.tag
def simplecms_get_page(parser, token):
    bits = token.contents.split()
    if len(bits) != 4:
        raise template.TemplateSyntaxError, "simplecms_get_page tag takes exactly three arguments"
    if bits[2] != 'as':
        raise template.TemplateSyntaxError, "second argument to the simplecms_get_page tag must be 'as'"
    return SimplecmsGetPageNode(bits[1], bits[3])


class SimplecmsGetPageNode(template.Node):
    def __init__(self, path, varname):
        self.varname, self.path = varname, path

    def render(self, context):
        try:
            context[self.varname] = Page.objects.from_path(self.path)
        except Page.DoesNotExist:
            pass
        return ''


@register.tag
def simplecms_get_nav(parser, token):
    bits = token.contents.split()
    if len(bits) != 4:
        raise template.TemplateSyntaxError, "simplecms_get_nav tag takes exactly three arguments"
    if bits[2] != 'as':
        raise template.TemplateSyntaxError, "second argument to the simplecms_get_nav tag must be 'as'"
    return SimplecmsGetNavNode(bits[1], bits[3])


class SimplecmsGetNavNode(template.Node):
    def __init__(self, nav, varname):
        self.varname, self.nav = varname, nav

    def render(self, context):
        try:
            log.debug("varname=%s, nav=%s", self.varname, self.nav)
            context[self.varname] = Page.objects.get_nav(self.nav)
            log.debug("varname=%s, nav=%s, obj=%s", self.varname, self.nav, context[self.varname])
        except Page.DoesNotExist:
            pass
        return ''


@register.filter
def simplecms_partition(snippets):
    """
    take ``snippets`` and divide them into above the app content
    and below the app content, returning the rendered content
    as a dict {'top': "...", 'bottom': "..."}
    """
    from simplecms.models import AppSnippet
    top = []
    bottom = []
    is_top = True
    for s in snippets:
        if isinstance(s, AppSnippet):
            is_top = False
            continue
        if is_top:
            top.append(s.render())
        else:
            bottom.append(s.render())
    return {'top': mark_safe("".join(top)), 'bottom': mark_safe("".join(bottom))}


@register.filter
def simplecms_excerpt(page, words):
    return page.excerpt(words)


@register.filter
def simplecms_chlocale(path, locale):
    from localeurl.templatetags.localeurl_tags import chlocale
    from localeurl.utils import strip_path
    try:
        orig_page = Page.objects.from_path(strip_path(path)[1])
    except Page.DoesNotExist:
        return chlocale(path, locale)
    translated = orig_page.get_translation(locale)
    if translated is None:
        if orig_page.is_app_node():
            return chlocale(path, locale)
        return ""
    return translated.get_absolute_url()


@register.assignment_tag
def simplecms_fragment(slug):
    try:
        return Fragment.objects.get(slug=slug)
    except Fragment.DoesNotExist:
        pass
