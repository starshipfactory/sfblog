from django import template
from simplecms import registry

register = template.Library()


@register.filter
def get_snippet_forms(formsets):
    forms = []
    for formset in formsets:
        for form in formset.forms:
            forms.append(form)
    return sorted(forms, key=lambda f: f.instance.order)


@register.inclusion_tag("simplecms/backend/nav.html")
def simplecms_backend_nav():
    context = {
        'panes': registry.get_dashboard_panes(),
    }
    return context


@register.inclusion_tag("simplecms/backend/dashboard.html")
def simplecms_backend_dashboard():
    context = {
        'panes': registry.get_dashboard_panes(),
    }
    return context
