from django.conf import settings

try:
    from localeurl.utils import locale_url
except ImportError:
    locale_url = lambda x: x  # NOQA


class LinkProvider(object):
    def get_links(self):
        raise NotImplementedError()


class PageLinkProvider(LinkProvider):
    def get_links(self):
        from simplecms.models import Page
        # filter linkable pages
        for lcode, name in settings.LANGUAGES:
            for page in Page.objects.filter(locale=lcode):
                if page.get_absolute_url():
                    url = page.get_absolute_url()
                    yield ("(%s) %s" % (lcode, page.title), url, page.get_level())
from simplecms import registry
registry.add_link_provider(PageLinkProvider)
