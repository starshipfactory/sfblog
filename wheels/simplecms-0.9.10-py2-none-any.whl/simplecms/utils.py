# -*- encoding: utf-8 -*-
from HTMLParser import HTMLParser, HTMLParseError
from django.utils.functional import SimpleLazyObject as DjangoSimpleLazyObject
from model_utils import Choices

import logging
logger = logging.getLogger(__name__)


try:
    from django.utils.text import truncate_words
except ImportError:
    from django.utils.text import Truncator

    def truncate_words(text, num_words):
        return Truncator(text).words(num_words, truncate=' ...')


def normalize_path(path):
    """
    normalize a full page path:
        "/foo/bar" -> "/foo/bar/"
        "foo/bar"  -> "/foo/bar/"
        "/"        -> "/"
        ""         -> "/"
    """
    if path == '/':
        return path
    return "/%s/" % path.strip("/")


def run_setup():
    from django.conf import settings
    from django.utils.importlib import import_module
    setup_callable = getattr(settings, "SIMPLECMS_SETUP_CALLBACK")
    components = setup_callable.split(".")
    module = import_module(".".join(components[:-1]))
    fn = getattr(module, components[-1])
    fn()


class SimpleLazyObject(DjangoSimpleLazyObject):
    def __repr__(self):
        if self._wrapped is None:
            self._setup()
        return repr(self._wrapped)


class LazyIterable(object):
    def __init__(self, fn):
        self.fn = fn

    def __iter__(self):
        return iter(self.fn())


class LazyChoices(Choices):
    def __init__(self, fn):
        self._fn = fn
        self._initialized = False

    def _initialize(self):
        if not self._initialized:
            super(LazyChoices, self).__init__(*self._fn())
            self._initialized = True

    def __len__(self):
        self._initialize()
        return super(LazyChoices, self).__len__()

    def __iter__(self):
        self._initialize()
        return super(LazyChoices, self).__iter__()

    def __getattr__(self, attname):
        self._initialize()
        return super(LazyChoices, self).__getattr__(attname)

    def __getitem__(self, index):
        self._initialize()
        return super(LazyChoices, self).__getitem__(index)

    def __repr__(self):
        self._initialize()
        return super(LazyChoices, self).__repr__()


class FindP(HTMLParser):
    def __init__(self, *args, **kwargs):
        HTMLParser.__init__(self, *args, **kwargs)
        self.in_p = 0
        self.result = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "p":
            self.in_p += 1

    def handle_endtag(self, tag):
        if tag.lower() == "p":
            self.in_p -= 1
            self.result.append(" ")

    def handle_entityref(self, name):
        entities = {
            'auml': u'ä',
            'ouml': u'ö',
            'uuml': u'ü',
            'Auml': u'Ä',
            'Ouml': u'Ö',
            'Uuml': u'Ü',
            'szlig': u'ß',
        }
        if self.in_p > 0:
            self.result.append(entities.get(name, ''))

    def handle_data(self, data):
        if self.in_p > 0:
            self.result.append(data)


def make_excerpt(text, words=None):
    from django.conf import settings

    try:
        p = FindP()
        p.feed(text)
    except HTMLParseError:
        return ""

    plain = "".join(p.result)
    if words is None:
        words = getattr(settings, 'SIMPLECMS_EXCERPT_WORDS', 200)
    res = truncate_words(plain, words)
    return res
