import sys
import json
from django.core.management.base import BaseCommand, CommandError
from simplecms.models import Page, Content, TextSnippet
from simplecms.template import Template
from collections import defaultdict
from django.db import transaction

cache_by_pk_model = {}
menus = {}
menuitems = {}
child_lists = defaultdict(lambda: [])
content = {}


def recurse_menuitem(item, parent, verbose):
    if verbose > 0:
        print "item: %s, parent: %s" % (item, parent)
    if item['fields']['parent'] is None:
        url = '/'
    else:
        url = item['fields']['url']
    caption = item['fields']['caption']
    pk = item['pk']
    c = Content.objects.create()
    p = Page.objects.create(title=caption, slug=url, parent=parent,
                            content=c, online=True)
    menuitems[pk] = p

    # add children of the root node as siblings:
    if item['fields']['parent'] is None:
        p = parent

    # process children:
    for child in child_lists[pk]:
        recurse_menuitem(cache_by_pk_model[(child, "treemenus.menuitem")], p,
                         verbose)


@transaction.commit_on_success
def import_old_simplecms(fname, verbose):
    raw_data = json.load(file(fname))

    template = Template.get_default()
    block = template.blocks[0]

    for item in raw_data:
        key = (item['pk'], item['model'])
        cache_by_pk_model[key] = item
        if item['model'] == "treemenus.menuitem":
            child_lists[item['fields']['parent']].append(item['pk'])

    for k, item in cache_by_pk_model.items():
        if item['model'] == "treemenus.menu":
            # create a navigation:
            name = item['fields']['name']
            p = Page.objects.create(title=name, slug=name.lower(), online=True)
            menus[item['pk']] = p

            recurse_menuitem(cache_by_pk_model[item['fields']['root_item'],
                                               "treemenus.menuitem"],
                             p, verbose)

    for k, item in cache_by_pk_model.items():
        if item['model'] == "simplecms.content":
            title = item['fields']['title']
            menuitem = item['fields']['menu_item']
            body = "<h1>%s</h1>%s" % (title, item['fields']['body'])

            try:
                p = menuitems[menuitem]
            except KeyError:
                print "menuitem %s not found" % menuitem
                raise
            p.description = item['fields']['teaser']
            TextSnippet.objects.create(body=body, content=p.content, order=0,
                                       block_slug=block.slug)


class Command(BaseCommand):
    help = "import from the old simplecms version (2010)"
    args = "[json-dump]"
    requires_model_validation = True

    def handle(self, *args, **options):
        if not len(args) == 1:
            raise CommandError("usage: %s simplecms_import_2010 %s"
                               % (sys.argv[0], self.args))
        from django.utils import translation
        from django.conf import settings

        translation.activate(settings.LANGUAGE_CODE)

        verbosity = int(options.get('verbosity', 1))
        import_old_simplecms(args[0], verbosity)
