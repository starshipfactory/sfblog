import sys
from django.core.management.base import BaseCommand, CommandError
from simplecms.models import Page


class Command(BaseCommand):
    help = "create a new simplecms navigation"
    args = "[locale] [slug] [title]"
    requires_model_validation = True

    def handle(self, *args, **options):
        if not len(args) == 3:
            raise CommandError("usage: %s simplecms_create_nav %s" % (sys.argv[0], self.args))
        from django.utils import translation
        from django.conf import settings

        translation.activate(settings.LANGUAGE_CODE)

        locale, slug, title = args
        verbosity = int(options.get('verbosity', 1))

        existing_navs = Page.objects.filter(parent=None, slug=slug).exclude(locale=locale)
        try:
            p = Page.objects.get(parent=None, slug=slug, locale=locale)
            raise CommandError("Navigation already exists: %s" % repr(p))
        except Page.DoesNotExist:
            pass
        p = Page.objects.create(slug=slug, title=title, locale=locale)

        try:
            existing_navs[0].translations.add(p)
        except IndexError:
            pass

        if verbosity > 0:
            print >> sys.stderr, "navigation created:", p
