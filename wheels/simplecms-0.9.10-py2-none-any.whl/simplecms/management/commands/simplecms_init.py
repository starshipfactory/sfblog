import sys
from django.core.management.base import BaseCommand
from simplecms.models import Page
from django.utils import translation
from django.utils.translation import ugettext as _
from django.conf import settings


class Command(BaseCommand):
    help = "initialize database for simplecms"
    requires_model_validation = True

    def maybe_make_nav(self, slug, lcode):
        navs = Page.objects.filter(parent=None)
        if navs.filter(locale=lcode, slug=slug).exists():
            nav = navs.get(locale=lcode, slug=slug)
        else:
            nav = Page.objects.create(slug=slug, title="%s Navigation" % (slug.title(),),
                                      locale=lcode)
            if self.verbosity > 0:
                print >> sys.stderr, "%s navigation created (locale=%s)" % (slug, lcode)
        return nav

    def handle(self, **options):
        self.verbosity = verbosity = int(options.get('verbosity', 1))

        navs_by_lang = {}
        for lcode, name in settings.LANGUAGES:
            translation.activate(lcode)
            nav = self.maybe_make_nav("main", lcode)
            navs_by_lang[lcode] = nav
        first_nav, rest_navs = navs_by_lang.values()[0], navs_by_lang.values()[1:]
        for nav in rest_navs:
            first_nav.translations.add(nav)

        all_nav_slugs = [n['slug']
                         for n in Page.objects.filter(parent=None).values('slug')]
        for nav_slug in all_nav_slugs:
            nav_objs = []
            for lcode, name in settings.LANGUAGES:
                translation.activate(lcode)
                nav = self.maybe_make_nav(nav_slug, lcode)
                for other in nav_objs:
                    other.translations.add(nav)
                nav_objs.append(nav)

        try:
            any_homepage = Page.objects.filter(slug="/")[0]
        except IndexError:
            any_homepage = None

        for lcode, name in settings.LANGUAGES:
            if not Page.objects.filter(slug="/", locale=lcode).exists():
                translation.activate(lcode)
                page = Page.objects.create(title=_("Homepage"), slug="/",
                                           parent=navs_by_lang[lcode], locale=lcode)
                if any_homepage is None:
                    any_homepage = page
                else:
                    any_homepage.translations.add(page)
                if verbosity > 0:
                    print >> sys.stderr, "homepage created (locale=%s)" % lcode
