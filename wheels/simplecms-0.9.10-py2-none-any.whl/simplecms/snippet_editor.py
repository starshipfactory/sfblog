import datetime
import logging
import json

from django import forms
from django.shortcuts import redirect, get_object_or_404
from django.core.urlresolvers import reverse
from django.views.generic.base import View
from django.forms.models import inlineformset_factory
from django.contrib.auth.decorators import user_passes_test
from django.contrib.admin.templatetags.admin_static import static
from django.contrib import messages
from django.utils.translation import ugettext as _
from django.conf import settings
from django.template.response import TemplateResponse

from simplecms.models import Page, Content
from simplecms.forms import PageModelForm, ContentModelForm
from simplecms.template import serialize_template_info
from simplecms import registry

try:
    from django.db.transaction import atomic as commit_on_success
except ImportError:
    from django.db.transaction import commit_on_success  # NOQA


logger = logging.getLogger("simplecms.snippet_editor")

require_staff = user_passes_test(lambda u: u.is_active and u.is_staff)


class SnippetEditor(View):
    http_method_names = ["get", "post"]
    template_name = "simplecms/backend/snippets/editor.html"

    def __init__(self, *args, **kwargs):
        self.snippet_models = registry.get_snippet_models()
        self.content_inlines = [
            inlineformset_factory(Content, m, extra=1,
                                  can_delete=True,
                                  form=m.get_backend_form())
            for m in self.snippet_models]
        super(SnippetEditor, self).__init__(*args, **kwargs)

    def get(self, request, obj_id=None, **kwargs):
        self._request = request
        self.url_kwargs = kwargs
        return self.add_edit_get(obj_id)

    @commit_on_success
    def post(self, request, obj_id=None, **kwargs):
        self._request = request
        self.url_kwargs = kwargs
        return self.add_edit_post(obj_id)

    def get_content(self, obj):
        if obj is None:
            return None
        return obj.content

    def get_formsets(self, content, method):
        if method == "post":
            formsets = [formset(self._request.POST, self._request.FILES,
                                instance=content)
                        for formset in self.content_inlines]
        else:
            formsets = [formset(instance=content)
                        for formset in self.content_inlines]
        return formsets

    def get_initial_values(self):
        initial_values = {}
        for m in self.snippet_models:
            initial_values[m.get_type()] = dict(m.get_default_values())
        return initial_values

    def get_form_media(self, contentform):
        form_media = forms.Media()
        form_media += contentform.media
        # media for other forms:
        for formname, form in self.get_extra_forms().items():
            form_media += form.media
        # snippet media:
        for m in self.snippet_models:
            form_media += m.get_media()
        for fs in self.get_formsets(None, ""):
            for f in fs.forms:
                form_media += f.media
        return form_media

    def save_extra(self, extra_forms, content, adding):
        for f in extra_forms:
            f.save()

    def make_context(self, contentform, formsets, post_url, instance=None):
        context = {
            'obj': instance,
            'template_info': json.dumps(
                self.get_template_info(instance)),
            'contentform': contentform,
            'formsets': formsets,
            'post_url': post_url,
            'form_media': self.get_form_media(contentform),
            'snippet_models': self.snippet_models,
            'initial_values': json.dumps(self.get_initial_values()),
            'ckeditor_config': json.dumps(
                settings.CKEDITOR_CONFIGS['default']),
        }
        context.update(self.get_extra_context(instance))
        return context

    def get_template_info(self, instance):
        return serialize_template_info()

    def make_error_list(self, _forms, formsets):
        errors = []
        for form in _forms:
            if form.is_bound:
                errors.append(form.errors)
        for fs in formsets:
            if fs.is_bound:
                errors.append(fs.non_form_errors())
                for err_in_fs in fs.errors:
                    errors.append(err_in_fs)
        return errors

    def get_content_initial(self):
        return {}

    def add_edit_get(self, obj_id):
        instance = None
        if obj_id:
            instance = get_object_or_404(self.get_query_set(), pk=obj_id)
            initial = {}
        else:
            initial = self.get_content_initial()
        content = self.get_content(instance)
        contentform = ContentModelForm(instance=content, prefix="content", initial=initial)
        formsets = self.get_formsets(content, "get")
        if instance:
            post_url = self.get_edit_url(instance)
        else:
            post_url = self.get_add_url()
        context = self.make_context(contentform, formsets, post_url, instance)
        context.update(self.get_extra_forms(instance))
        return TemplateResponse(self._request, self.template_name,
                                context=context)

    def add_edit_post(self, obj_id=None):
        instance = None
        if obj_id:
            instance = self.get_query_set().get(pk=obj_id)
        content = self.get_content(instance)
        contentform = ContentModelForm(self._request.POST, self._request.FILES,
                                       prefix="content", instance=content)
        formsets = self.get_formsets(content, "post")
        extra_forms = self.get_extra_forms(instance, method="post")

        context = {}
        if contentform.is_valid() and all(fs.is_valid() for fs in formsets)\
                and all(f.is_valid() for f in extra_forms.values()):

            newcontent = contentform.save()
            self.save_extra(extra_forms, newcontent, obj_id is None)
            formsets = self.get_formsets(newcontent, "post")

            for fs in formsets:
                fs.is_valid()
                fs.save()

            if instance:
                return self.redirect_success(newcontent, "edit")
            else:
                return self.redirect_success(newcontent, "add")
        else:
            all_forms = extra_forms.values()
            all_forms.append(contentform)
            context['errors'] = self.make_error_list(all_forms, formsets)

        if instance:
            post_url = self.get_edit_url(instance)
        else:
            post_url = self.get_add_url()

        context.update(self.make_context(contentform, formsets,
                                         post_url, instance))
        context.update(extra_forms)
        return TemplateResponse(self._request, self.template_name,
                                context=context)

    def get_extra_context(self, instance):
        return {}

    def redirect_success(self, content, action):
        raise NotImplementedError("please implement redirect_success")

    def get_edit_url(self, instance):
        raise NotImplementedError("please implement get_edit_url")

    def get_add_url(self):
        raise NotImplementedError("please implement get_add_url")

    def get_extra_forms(self, instance=None, method="get"):
        raise NotImplementedError("please implement get_extra_forms")

    def get_query_set(self):
        raise NotImplementedError("please implement get_query_set")


class AdminSnippetEditor(SnippetEditor):
    template_name = "simplecms/backend/admin_editor.html"
    """
    SnippetEditor for use in the admin interface
    """
    def get_add_url(self):
        info = self.model._meta.app_label, self.model._meta.module_name
        return reverse("admin:%s_%s_add" % info)

    def get_edit_url(self, instance):
        info = self.model._meta.app_label, self.model._meta.module_name
        return reverse("admin:%s_%s_change" % info, args=[instance.pk])

    def get_changelist_url(self):
        info = self.model._meta.app_label, self.model._meta.module_name
        return reverse("admin:%s_%s_changelist" % info)

    def get_extra_forms(self, instance=None, method="get"):
        return {}

    def get_extra_context(self, instance):
        context = {
            'verbose_name': self.model._meta.verbose_name,
            'changelist_url': self.get_changelist_url(),
        }
        if instance:
            context['edit_url'] = self.get_edit_url(instance)
        return context

    def get_instance_from_content(self, content):
        raise NotImplementedError("please implement get_instance_from_content")

    def redirect_success(self, content, action):
        instance = self.get_instance_from_content(content)
        if action == "add":
            messages.add_message(self._request, messages.SUCCESS,
                                 _('%(model)s "%(title)s" has been added successfully'
                                   % {'model': self.model._meta.verbose_name,
                                      'title': instance.title}))
        elif action == "edit":
            messages.add_message(self._request, messages.SUCCESS,
                                 _('%(model)s "%(title)s" has been edited successfully'
                                   % {'model': self.model._meta.verbose_name,
                                      'title': instance.title}))
        if self._request.POST.has_key("_continue"):  # NOQA
            return redirect(self.get_edit_url(instance))
        info = self.model._meta.app_label, self.model._meta.module_name
        return redirect("admin:%s_%s_changelist" % info)

    def get_form_media(self, contentform):
        """
        include the default admin js stuff
        """
        js = [
            'core.js',
            'jquery.js',
            'jquery.init.js',
        ]
        extra = forms.Media(js=[static('admin/js/%s' % url) for url in js])
        return extra + super(AdminSnippetEditor, self).get_form_media(contentform)


class PageEditor(SnippetEditor):
    template_name = "simplecms/backend/page/edit.html"
    _old_slug = None

    def get_query_set(self):
        return Page.objects.select_related("app_page", "parent")

    def get_add_url(self):
        return reverse("simplecms-backend-page-add", kwargs=dict(lang=self.kwargs['lang']))

    def get_edit_url(self, obj):
        return reverse("simplecms-backend-page-edit",
                       kwargs=dict(obj_id=obj.id, lang=self.kwargs['lang']))

    def add_edit_post(self, obj_id):
        if obj_id:
            page = get_object_or_404(Page, pk=obj_id)
            self._old_slug = page.slug
        resp = super(PageEditor, self).add_edit_post(obj_id)
        Page.objects.update_denorm()
        return resp

    def save_extra(self, extra_forms, content, adding):
        form = extra_forms['pageform']
        page = form.save(commit=False)
        page.content = content
        page.locale = self.url_kwargs['lang']
        if self._old_slug:
            if self._old_slug == "/" or page.is_app_node():
                page.slug = self._old_slug
        page.save()
        form.save_m2m()

    def redirect_success(self, content, action):
        page = content.page
        if action == "add":
            messages.add_message(self._request, messages.SUCCESS,
                       _('Page "%s" has been added successfully' % page.title))
        elif action == "edit":
            messages.add_message(self._request, messages.SUCCESS,
                    _('Page "%s" has been edited successfully' % page.title))
        if self._request.POST.has_key("_continue"):  # NOQA
            return redirect("simplecms-backend-page-edit",
                            obj_id=content.page.id, lang=self.url_kwargs['lang'])
        return redirect("simplecms-backend-pages", lang=self.url_kwargs['lang'])

    def get_extra_context(self, instance):
        parent_id = self._request.GET.get('parent')
        if parent_id is None:
            parent_id = self._request.POST.get('parent')
        parent = None
        if parent_id:
            parent = self.get_query_set().get(pk=parent_id)

        return {
            'parent': parent,
            'content_locale': self.url_kwargs['lang'],
        }

    def get_extra_forms(self, instance=None, method="get"):
        initial_data = {}
        parent = self.get_extra_context(instance)['parent']
        if instance is None:
            initial_data['created'] = datetime.datetime.now
        if parent:
            initial_data['parent'] = parent.id
        if method == "post":
            pageform = PageModelForm(self.url_kwargs['lang'],
                                     self._request.POST, self._request.FILES,
                                     instance=instance, initial=initial_data)
        else:
            pageform = PageModelForm(self.url_kwargs['lang'],
                                     instance=instance, initial=initial_data)

        return {
            'pageform': pageform,
        }
