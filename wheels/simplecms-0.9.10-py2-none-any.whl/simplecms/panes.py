from django.core.urlresolvers import reverse
from django.utils.translation import ugettext as _


class DashboardPane(object):
    verbose_name = ""

    @property
    def name(self):
        return self.verbose_name

    @property
    def url(self):
        raise NotImplementedError()


class PagesDashboardPane(DashboardPane):
    verbose_name = _("Pages")

    @property
    def url(self):
        return reverse("simplecms-backend-pages")
