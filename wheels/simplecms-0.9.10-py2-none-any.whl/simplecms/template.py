class TemplateBlock(object):
    def __init__(self, name, slug):
        self.name = name
        self.slug = slug

    @property
    def id(self):
        return "%s.%s" % (self.template_slug, self.slug)

    def set_template_slug(self, slug):
        """
        called by Template when we are added
        to generate a unique id
        """
        self.template_slug = slug


class Template(object):
    def __init__(self, name, slug, desc, path):
        self.name = name
        self.slug = slug
        self.desc = desc
        self.path = path
        self.blocks = []
        self.block_by_slug = {}

    @classmethod
    def get_default(cls):
        return cls.get_by_slug("default")

    @classmethod
    def get_by_slug(cls, slug):
        from simplecms.registry import get_template
        return get_template(slug)

    def get_full_path(self):
        return "simplecms/%s" % self.path

    def get_block(self, slug):
        return self.block_by_slug[slug]

    def add_block(self, block):
        self.blocks.append(block)
        self.block_by_slug[block.slug] = block
        block.set_template_slug(self.slug)

    def add_blocks(self, blocks):
        for b in blocks:
            self.add_block(b)

    @property
    def id(self):
        return self.slug

    def __unicode__(self):
        return self.name


def serialize_template_info(templates=None):
    from simplecms.registry import get_templates
    if templates is None:
        templates = get_templates()

    all_blocks = []
    res = {
        'templates': {},
        'blocks': {},
    }
    for t in templates:
        blocks = []
        for order, b in enumerate(t.blocks):
            tmp_block = {
                'id': b.id,
                'name': b.name,
                'order': order,
                'slug': b.slug,
            }
            all_blocks.append(tmp_block)
            blocks.append(tmp_block)
        res['templates'][t.id] = {
            'blocks': [b['id'] for b in blocks],
            'slug': t.slug,
            'name': t.name,
        }
    for b in all_blocks:
        res['blocks'][b['id']] = b
    return res
