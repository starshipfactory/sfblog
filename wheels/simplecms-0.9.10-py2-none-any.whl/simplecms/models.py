# -*- encoding: utf-8 -*-
import collections

from django.db import models, transaction
from django.db.models import F
from django import forms
from django.core.exceptions import ImproperlyConfigured
from django.utils.safestring import mark_safe
from django.template.loader import render_to_string
from django.template.defaultfilters import slugify
from django.utils.translation import ugettext as _, get_language
from django.conf import settings

from mptt.models import (MPTTModel, TreeManager, TreeForeignKey,
                         TreeManyToManyField, TreeOneToOneField)
from model_utils.models import TimeStampedModel
from model_utils.fields import AutoCreatedField, AutoLastModifiedField
from model_utils.managers import InheritanceManager

from imagetools.models import ThumbnailField
from simplecms import registry
from simplecms.utils import (LazyIterable, LazyChoices, SimpleLazyObject,
                             run_setup, normalize_path)

import logging
logger = logging.getLogger(__name__)
debug = logger.debug

run_setup()
from simplecms import links  # NOQA


class PageManager(TreeManager):
    use_for_related_fields = True

    def online(self, locale=None):
        if locale is None:
            locale = get_language()
        return self.get_query_set().filter(_show_online=True, locale=locale)

    def in_navigation(self, locale=None):
        if locale is None:
            locale = get_language()
        return self.get_query_set().filter(_show_online=True,
                                           _show_in_navigation=True,
                                           locale=locale)

    def get_nav(self, slug, locale=None):
        if locale is None:
            locale = get_language()
        return self.get_query_set().get(slug=slug, parent=None, locale=locale)

    def for_app(self, url_name, app_name, namespace, args, kwargs, locale=None):
        if locale is None:
            locale = get_language()
        if app_name is None:
            app_name = ""
        try:
            ap = AppPage.objects.get(app_name=app_name, url_name=url_name,
                                     namespace=namespace, page__locale=locale)
            return ap.page
        except AppPage.DoesNotExist:
            return None

    def from_path(self, path, locale=None, **kwargs):
        if locale is None:
            locale = get_language()
        debug("looking up path %s (locale=%s)", path, locale)
        try:
            full_path = normalize_path(path)
            return self.get_query_set()\
                .select_related("parent", "app_page")\
                .get(_full_path=full_path, locale=locale, **kwargs)
        except Page.DoesNotExist:
            pass

        from django.core.urlresolvers import resolve, Resolver404
        try:
            match = resolve(path)
            if match.view_name != 'simplecms.views.render_page':
                page = self.for_app(match.url_name, match.app_name,
                                    match.namespace, match.args, match.kwargs, locale)
                if page is not None:
                    return page
        except Resolver404:
            pass

        path = path.strip("/")
        # special case: home page
        if path == "":
            return self.get_query_set()\
                .select_related("parent", "app_page", "content__template")\
                .get(slug="/", locale=locale, **kwargs)

        def _find_page_recursive(cur_page, elements):
            """
            find the Page matching the path tokens in ``elements``,
            searching the children of ``cur_page``
            """
            debug("_find_page_recursive(%s, %s)" % (cur_page, elements))
            try:
                head = elements[0]
                rest = elements[1:]
            except IndexError:
                # we have already consumed the whole path.
                debug(">>> %s", cur_page)
                return cur_page

            debug("checking for child %s below %s", head, cur_page)
            child = cur_page.children.get(slug=head, **kwargs)
            debug("found page: %s", child)
            return _find_page_recursive(child, rest)

        roots = list(self.get_query_set().filter(parent=None, locale=locale))
        try:
            roots.append(self.get_query_set().get(slug="/", locale=locale))
        except Page.DoesNotExist:
            raise ImproperlyConfigured(u"the homepage has not been created")
        path_lst = path.split("/")
        for root in roots:
            try:
                return _find_page_recursive(root, path_lst)
            except Page.DoesNotExist:
                pass
        raise Page.DoesNotExist("page '%s' (locale=%s) not found" % (full_path, locale))

    def create(self, **kwargs):
        if not 'content' in kwargs:
            kwargs['content'] = Content.objects.create()
        return super(PageManager, self).create(**kwargs)

    def update_denorm(self):
        pages = self.get_query_set().filter(app_page=None)
        # set to known-good values
        pages.update(_show_in_navigation=F("in_navigation"))
        pages.update(_show_online=F("online"))
        for p in self.get_query_set().filter(parent__isnull=False)\
                .select_related("parent", "app_page"):
            try:
                if p.app_page is None:
                    p._full_path = p.get_path(force=True)
            except AppPage.DoesNotExist:
                p._full_path = p.get_path(force=True)
                p._full_path = p.get_path(force=True)
            p._show_online = p.show_online(force=True)
            p._show_in_navigation = p.show_in_navigation(force=True)
            p.save()

        transaction.commit_unless_managed()


class Page(MPTTModel):
    """
    A Page object is a node in the navigation hierarchy
    """
    title = models.CharField(_("title"), max_length=255)
    slug = models.CharField(_("slug"), max_length=255, db_index=True)

    online = models.BooleanField(_("online"), blank=True, default=False,
                                 db_index=True)
    in_navigation = models.BooleanField(_("show in nav"), blank=True,
                                        default=True, db_index=True)
    parent = TreeForeignKey('self', null=True, blank=True,
                            related_name="children", db_index=True)
    locale = models.CharField(max_length=5, default='', db_index=True)
    content = models.OneToOneField("Content")

    # meta-data:
    created = AutoCreatedField(_("created"), editable=True)
    modified = AutoLastModifiedField(_("modified"))

    description = models.TextField(_("description"), blank=True, null=True,
                                   default="")
    keywords = models.TextField(_("keywords"), blank=True, null=True,
                                default="")

    # values calculated in Page.objects.update_denorm
    _full_path = models.TextField(null=True, blank=True, editable=False, db_index=True)
    _show_in_navigation = models.NullBooleanField(null=True, blank=True,
                                                  editable=False)
    _show_online = models.NullBooleanField(null=True, blank=True,
                                           editable=False)

    translations = TreeManyToManyField("self", symmetrical=True, blank=True,
                                       verbose_name=_("translations"),
                                       help_text=_(u"Select which pages in other "
                                                   u"languages correspond to this page"))

    objects = PageManager()

    class MPTTMeta:
        pass

    class Meta:
        ordering = ['tree_id', 'lft']

    def __repr__(self):
        if self.is_nav_root():
            return "<Page: navigation %s (locale=%s)>" % (self.slug, self.locale)
        return "<Page: %s (locale=%s)>" % (self.get_path(), self.locale)

    def __unicode__(self):
        return self.title

    def get_translation(self, locale):
        if locale == self.locale:
            return self
        # not filtering in the DB because we want to profit from
        # .prefetch_related() optimizations
        all_trans = list(self.translations.all())
        for p in all_trans:
            if p.locale == locale:
                return p

    def all_locales(self):
        for code, name in settings.LANGUAGES:
            if code == self.locale:
                yield (code, self)
            else:
                yield (code, self.get_translation(code))

    def render(self):
        res = {}
        snippets_by_block = self.get_blocks()

        for block in self.content.template.blocks:
            block_content = "".join([s.render()
                                     for s in snippets_by_block[block.slug]])
            res[block.slug] = mark_safe(block_content)
        return res

    def get_blocks(self):
        all_snippets = self.content.snippets()
        snippets_by_block = collections.defaultdict(lambda: [])

        for snippet in all_snippets:
            snippets_by_block[snippet.block_slug].append(snippet)
        return snippets_by_block

    def get_media(self):
        m = forms.Media()
        for s in self.content.snippets():
            m += s.get_frontend_media()
        return m

    def get_path(self, force=False):
        if not force and self._full_path:
            return self._full_path
        if self.is_nav_root():
            return "/"
        if self.is_homepage():
            return "/"
        if self.parent:
            return self.parent.get_path(force) + self.slug + "/"
        else:
            return "/" + self.slug + "/"

    def is_nav_root(self):
        return self.parent is None

    def is_app_node(self):
        try:
            if self.app_page is not None:
                return True
            return False
        except AppPage.DoesNotExist:
            return False

    def is_deletable(self):
        if self.is_nav_root() or self.is_app_node() or self.is_homepage():
            return False
        return True

    def is_leaf_in_nav(self):
        return self.is_leaf_node() or not any(p.show_in_navigation()
                                              for p in self.get_descendants())

    def is_movable(self):
        return not self.is_nav_root()

    def is_movable_same_parent(self):
        if self.is_homepage():
            return True
        return False

    def show_online(self, force=False):
        if not force and self._show_online is not None:
            return self._show_online
        return self.online and all(p.online for p in self.get_ancestors())

    def show_in_navigation(self, force=False):
        if not force and self._show_in_navigation is not None:
            return self._show_in_navigation
        if not self.in_navigation:
            return False
        if not self.online:
            return False
        if self.parent is None:
            return True
        return self.parent.show_in_navigation(force)

    def is_homepage(self):
        return self.slug == "/"

    def can_have_content(self):
        if self.is_nav_root():
            return False
        return True

    def can_have_children(self):
        if not self.is_app_node():
            return True
        else:
            return self.app_page.can_have_children

    def partition_snippets(self):
        import warnings
        warnings.warn(DeprecationWarning("``Page.partition_snippets`` is "
            "deprecated, use the ``simplecms_partition`` filter"))
        snippets = self.content.snippets()
        top = []
        bottom = []
        is_top = True
        for s in snippets:
            if isinstance(s, AppSnippet):
                is_top = False
                continue
            if is_top:
                top.append(s)
            else:
                bottom.append(s)
        return top, bottom

    def get_absolute_url(self):
        from django.core.urlresolvers import reverse, NoReverseMatch
        if self.is_app_node():
            try:
                if 'localeurl' in settings.INSTALLED_APPS:
                    return reverse(self.app_page.get_viewname(), kwargs=dict(locale=self.locale))
                return reverse(self.app_page.get_viewname())
            except NoReverseMatch:
                debug("failed to resolve app page %s, locale=%s",
                      self.app_page.get_viewname(),
                      self.locale)
                return None
        if not self.parent and self.slug != "/":
            return None  # navigations have no URL
        if 'localeurl' in settings.INSTALLED_APPS:
            from localeurl.utils import locale_url
            return locale_url(self.get_path(), locale=self.locale)
        return self.get_path()

    def get_breadcrumb_pages(self):
        return self.get_ancestors().filter(parent__isnull=False)

    def excerpt(self, words=None):
        return self.content.excerpt(words=words)


class AppPage(models.Model):
    page = TreeOneToOneField(Page, related_name="app_page")
    app_name = models.CharField(max_length=100, default="", blank=True)
    url_name = models.CharField(max_length=100, default="")
    namespace = models.CharField(max_length=100, default="", blank=True)
    can_have_children = models.BooleanField()

    description = models.TextField("Decription shown to the user", default="")
    edit_link = models.CharField(max_length=100, default="", blank=True)

    def save(self, *args, **kwargs):
        snippets = self.page.content.snippets()
        app_snippets = [s for s in snippets
                        if s.get_type() == "appsnippet"]
        if len(app_snippets) == 0:
            s = AppSnippet.objects.create(content=self.page.content,
                                          order=0)
        super(AppPage, self).save(*args, **kwargs)

    def get_viewname(self):
        res = []
        if self.namespace:
            res.append(self.namespace)
        if self.app_name:
            res.append(self.app_name)
        res.append(self.url_name)
        return u":".join(res)

    def __unicode__(self):
        return self.get_viewname()


class Content(models.Model):
    """
    presentational information: template, ...
    not only used by Page, potentially also for others
    """
    TEMPLATE_CHOICES = LazyChoices(
        lambda: [(t.slug, t.name) for t in registry.get_templates()]
    )
    template_slug = models.SlugField(_("Template"),
                                     db_column="template",
                                     default="default",
                                     choices=TEMPLATE_CHOICES)

    def snippets(self):
        return self.snippet_set.select_subclasses()

    def clone(self, new_instance):
        new_instance.template_slug = self.template_slug

    @property
    def template(self):
        from simplecms.template import Template
        return Template.get_by_slug(self.template_slug)

    def excerpt(self, words=None):
        from simplecms.utils import make_excerpt
        for s in self.snippets():
            if s.get_type() == "textsnippet":
                res = make_excerpt(s.body, words)
                if res:
                    return res
        return ""

#==============================================================================


class RelatedInheritanceManager(InheritanceManager):
    use_for_related_fields = True


class Snippet(models.Model):
    content = models.ForeignKey(Content)
    order = models.PositiveIntegerField()
    block_slug = models.SlugField(db_column="block", default="")

    objects = RelatedInheritanceManager()

    class Meta:
        ordering = ["order"]

    def __unicode__(self):
        return "%s" % self.get_type()

    def clone(self, new_instance):
        new_instance.order = self.order
        new_instance.block_slug = self.block_slug
        # "content" is handeled outside of this

    @classmethod
    def get_type(cls):
        return cls.__name__.lower()

    @classmethod
    def is_editable(cls):
        return True

    @classmethod
    def get_verbose_name(cls):
        return cls._meta.verbose_name

    @classmethod
    def get_description(cls):
        return ""

    def get_snippet_templates(self):
        typ = self.get_type()
        return ["simplecms/snippets/%s.html" % typ]

    def render(self):
        return mark_safe(render_to_string(self.get_snippet_templates(),
            {'obj': self}))

    @classmethod
    def get_snippet_form_template(self):
        return "simplecms/backend/snippets/snippet_form.html"

    @classmethod
    def get_help_text(cls):
        return u""

    @classmethod
    def get_backend_form(cls):
        from django.forms.models import ModelForm

        class SnippetForm(ModelForm):
            order = forms.CharField(widget=forms.HiddenInput)

            class Meta:
                model = cls
        return SnippetForm

    @classmethod
    def get_default_values(cls):
        form = cls.get_backend_form()
        form_inst = form()
        return [(field_name, unicode(field.initial))
                for (field_name, field) in form_inst.fields.items()
                if field.initial]

    @classmethod
    def get_media(cls):
        return forms.Media()

    @classmethod
    def get_frontend_media(cls):
        return forms.Media()


class AppSnippet(Snippet):
    """
    this is a placeholder for dynamic content
    """

    class Meta:
        verbose_name = _(u"Application Placeholder")

    def render(self):
        return u""

    @classmethod
    def is_editable(cls):
        return False

    @classmethod
    def get_snippet_form_template(self):
        return "simplecms/backend/snippets/appsnippet_form.html"

    def get_app_page(self):
        return self.content.page.app_page

    def get_help_text(self):
        return self.get_app_page().description

    def get_edit_link(self):
        return self.get_app_page().edit_link

    @classmethod
    def get_media(cls):
        return forms.Media(js=('simplecms/backend/js/snippets/appsnippet.js',))


class TextSnippet(Snippet):
    STYLE = LazyChoices(lambda: registry.get_snippet_settings(
        "textsnippet", "styles", []))

    body = models.TextField(_(u'body'))
    style = models.CharField(_(u'style'), choices=STYLE, max_length=100,
                             blank=True, null=True)

    class Meta:
        verbose_name = _(u"Text Content")

    def clone(self, new_instance):
        super(TextSnippet, self).clone(new_instance)
        new_instance.body = self.body
        new_instance.style = self.style

    @classmethod
    def get_description(cls):
        return _("Formatted Text")

    @classmethod
    def get_media(cls):
        return forms.Media(
            js=('simplecms/backend/js/snippets/textsnippet.js',))

    @classmethod
    def get_snippet_form_template(self):
        return "simplecms/backend/snippets/textsnippet_form.html"


def make_image_filename(instance, filename):
    try:
        ext = u".%s" % filename.split(".")[-1]
    except IndexError:
        ext = u""
    return "snippet_images/%s" % slugify(instance.title) + ext


class ImageSnippet(Snippet):
    STYLE = LazyChoices(lambda:
            registry.get_snippet_settings("imagesnippet", "styles", []))
    SIZE = LazyChoices(lambda:
            registry.get_snippet_settings("imagesnippet", "content_sizes"))

    title = models.CharField(_("title"), max_length=255)
    description = models.TextField(_("image description"),
            blank=True, default="")
    style = models.CharField(_("style"), choices=STYLE,
            max_length=100, blank=True, null=True)
    size = models.CharField(_("image size"), choices=SIZE, max_length=100)
    image = ThumbnailField(_("image"),
                           sizes=LazyIterable(
                               lambda: registry.get_snippet_settings("imagesnippet", "sizes")
                               + [(400, 400, True, "backend")]),
                           upload_to=make_image_filename, max_length=255,
                           width_field="image_width", height_field="image_height")
    link = models.CharField(_(u'link'), max_length=200, default="", blank=True,
                            help_text=_(u"Enter URL if you want to "
                                        u"link this image to another page"))
    link_target = models.CharField(_(u'link target'), max_length=25, default="", blank=True)

    image_width = models.IntegerField()
    image_height = models.IntegerField()

    class Meta:
        verbose_name = _(u"Image Content")

    def clone(self, new_instance):
        super(ImageSnippet, self).clone(new_instance)
        for field in ["title", "description", "style", "size", "image",
                      "link", "link_target", "image_width", "image_height"]:
            setattr(new_instance, field, getattr(self, field))

    def get_snippet_templates(self):
        typ = self.get_type()
        return ["simplecms/snippets/%s_%s.html" % (typ, self.style),
                "simplecms/snippets/%s.html" % typ]

    @classmethod
    def get_description(cls):
        return _("Automatically resized image")

    @classmethod
    def get_snippet_form_template(self):
        return "simplecms/backend/snippets/imagesnippet_form.html"

    @classmethod
    def get_backend_form(cls):
        SnippetForm = super(ImageSnippet, cls).get_backend_form()

        class ImageSnippetForm(SnippetForm):
            class Meta:
                model = cls
                exclude = ["image_width", "image_height"]
        return ImageSnippetForm

    @classmethod
    def get_media(cls):
        return forms.Media(
            js=('simplecms/backend/js/snippets/imagesnippet.js',))


class VideoSnippet(Snippet):
    """
    embed videos (youtube, vimeo, ...) into your page
    needs django-oembed if used with the shipped template
    """
    STYLE = LazyChoices(lambda: registry.get_snippet_settings(
        "videosnippet", "styles", []))

    title = models.CharField(_(u'title'), max_length=255)
    description = models.TextField(_("video description"))
    url = models.URLField()
    width = models.PositiveIntegerField(_(u'width'), default=SimpleLazyObject(lambda:
                registry.get_snippet_settings("videosnippet", "width", 320)))
    height = models.PositiveIntegerField(_(u'height'), default=SimpleLazyObject(lambda:
                registry.get_snippet_settings("videosnippet", "height", 240)))
    style = models.CharField(_(u'style'), choices=STYLE, max_length=100,
            blank=True, null=True)

    class Meta:
        verbose_name = _(u"Video Content")

    def clone(self, new_instance):
        super(VideoSnippet, self).clone(new_instance)
        for field in ["title", "description", "style", "width", "height",
                      "url"]:
            setattr(new_instance, field, getattr(self, field))

    def size(self):
        return "%dx%d" % (self.width, self.height)

    @classmethod
    def get_description(cls):
        return _(u"Embed external video from YouTube, Vimeo, Flickr, …")

    @classmethod
    def get_snippet_form_template(self):
        return "simplecms/backend/snippets/videosnippet_form.html"

    @classmethod
    def get_media(cls):
        return forms.Media(
            js=('simplecms/backend/js/snippets/videosnippet.js',))


class Fragment(TimeStampedModel):
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)
    body = models.TextField(_(u'body'), default="", blank=True)

    class Meta:
        verbose_name = _(u"Fragment")
        verbose_name_plural = _(u"Fragments")

    def __unicode__(self):
        return self.name


class FragmentSnippet(Snippet):
    fragment = models.ForeignKey(Fragment, verbose_name=_(u'fragment'))

    class Meta:
        verbose_name = _(u"Fragment Content")

    def clone(self, new_instance):
        super(FragmentSnippet, self).clone(new_instance)
        new_instance.fragment = self.fragment

    @classmethod
    def get_description(cls):
        return _("Boilerplate text block")
