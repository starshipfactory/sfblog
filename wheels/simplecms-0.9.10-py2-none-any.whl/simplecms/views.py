from django.shortcuts import render_to_response
from django.template import RequestContext, loader
from django.conf import settings
from django.utils.http import urlencode
from django import http

from simplecms.models import Page
from simplecms.signals import pre_render


def render_page(request, path, template_name="simplecms/content.html",
                extra_context=None):
    if not path:
        path = "/"

    # APPEND_SLASH did not take effect on this url
    # because of the "catch-all" urlconf entry,
    # so do it here
    if not path.endswith("/") and settings.APPEND_SLASH:
        new_path = "/%s/?%s" % (request.path.strip("/"), urlencode(request.GET, doseq=True))
        return http.HttpResponsePermanentRedirect(new_path)

    try:
        page = Page.objects.from_path(path, online=True)
    except Page.DoesNotExist:
        raise http.Http404("page not found")
    if not page.show_online():
        raise http.Http404("page not online")

    # pre_render signal can override the response:
    for receiver, resp in pre_render.send(sender=page, request=request, page=page):
        if resp is not None:
            return resp

    templates = []
    if page.content.template_slug:
        templates.insert(0, page.content.template.get_full_path())
    templates.append(template_name)

    context = {'simplecms_page': page}
    if extra_context:
        context.update(extra_context)

    return render_to_response(templates, context,
                              context_instance=RequestContext(request))


def sitemap(request, template_name="simplecms/sitemap.html", status_code=200):
    context = {
        'navs': [
            p.slug
            for p in Page.objects.filter(_show_online=True, parent=None)
        ],
    }
    body = loader.render_to_string(template_name, context,
                                   context_instance=RequestContext(request))
    return http.HttpResponse(body, status=status_code)
