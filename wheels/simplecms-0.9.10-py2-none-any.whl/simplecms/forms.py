from django import forms
from django.forms.models import ModelForm
from django.utils.translation import ugettext_lazy as _

from django.contrib.admin.widgets import AdminSplitDateTime, FilteredSelectMultiple

from simplecms.models import Page, Content


def add_error(the_form, key, value):
    if not key in the_form._errors:
        the_form._errors[key] = the_form.error_class()
    the_form._errors[key].append(value)


class CheckboxFirstInput(forms.CheckboxInput):
    label_last = True


class PageModelForm(ModelForm):
    parent = forms.ModelChoiceField(queryset=Page.objects.none(),
            widget=forms.HiddenInput)
    created = forms.DateTimeField(label=_("created"), widget=AdminSplitDateTime)
    translations = forms.ModelMultipleChoiceField(
        label=_("translations"),
        required=False,
        queryset=Page.objects.all(),
        widget=FilteredSelectMultiple(_("translations"), False))

    def __init__(self, locale, *args, **kwargs):
        super(PageModelForm, self).__init__(*args, **kwargs)
        self.fields['parent'].queryset = Page.objects.filter(locale=locale)
        self.fields['translations'].queryset = Page.objects.exclude(locale=locale)\
            .exclude(parent=None)
        self.locale = locale

    def clean(self):
        cd = self.cleaned_data = super(PageModelForm, self).clean()
        parent = cd.get('parent', None)
        if not parent or not parent.can_have_children() and\
                (parent.is_app_node() and not self.instance.is_app_node()):
            add_error(self, "title", _("invalid parent node"))
        new_path = parent.get_path() + cd.get('slug', '') + "/"
        if self.instance.pk is None:
            # new page, page with new_path must not exist
            try:
                Page.objects.from_path(new_path, locale=self.locale)
                # TODO: how to word this better?
                add_error(self, "slug", _("slug must be unique on this level"))
            except Page.DoesNotExist:
                pass
        else:
            # editing page, one page with new_path may exist
            try:
                page = Page.objects.from_path(new_path, locale=self.locale)
                if page.id != self.instance.id:
                    # TODO: how to word this better?
                    add_error(self, "slug", _("slug must be unique on this level"))
            except Page.DoesNotExist:
                pass

        return cd

    @property
    def media(self):
        from django.conf import settings

        js = ['js/core.js', 'js/admin/RelatedObjectLookups.js',
              'js/jquery.min.js', 'js/jquery.init.js']

        if hasattr(settings, "ADMIN_MEDIA_PREFIX"):
            files = ['%s%s' % (settings.ADMIN_MEDIA_PREFIX, url) for url in js]
            return forms.Media(js=files)\
                + super(PageModelForm, self).media
        else:
            from django.contrib.admin.templatetags.admin_static import static
            return forms.Media(js=[static("admin/%s" % path) for path in js])\
                + super(PageModelForm, self).media

    class Meta:
        model = Page
        exclude = ["content", "locale"]


class ContentModelForm(ModelForm):
    class Meta:
        model = Content


class TranslateForm(ModelForm):
    def __init__(self, to_lang, *args, **kwargs):
        super(TranslateForm, self).__init__(*args, **kwargs)
        self.fields['parent'].queryset = Page.objects.filter(locale=to_lang)
        self.fields['parent'].required = True

    class Meta:
        model = Page
        fields = ["title", "slug", "parent"]
