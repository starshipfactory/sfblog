"""Tests for django-annoying"""

from .decorators import AJAXRequestTestCase, RenderToTestCase
from .fields import FieldsTestCase
