"""Mandatory models.py for tests to work"""
