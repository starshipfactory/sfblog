from warnings import warn

warn("IPython.utils.pickleutil has moved to ipykernel.pickleutil")

from ipykernel.pickleutil import *
