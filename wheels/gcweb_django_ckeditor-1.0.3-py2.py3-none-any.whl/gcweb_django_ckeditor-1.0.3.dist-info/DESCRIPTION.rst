A small Django application that makes it easy to use CKEditor for form textareas.


