"""Management module of Zinnia"""
