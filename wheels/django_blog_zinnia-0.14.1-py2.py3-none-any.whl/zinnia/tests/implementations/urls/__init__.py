"""
URLs components needed for tests.
"""
