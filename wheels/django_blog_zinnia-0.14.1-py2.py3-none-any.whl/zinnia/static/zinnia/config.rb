# Require any additional compass plugins here.
require 'susy'
# Project directories
css_dir = "css"
sass_dir = "sass"
images_dir = "img"
javascripts_dir = "js"
# CSS generation
output_style = :compressed
line_comments = false
relative_assets = true
