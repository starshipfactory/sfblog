version = (1, 2, 0)
version_string = '.'.join(map(str, version))
